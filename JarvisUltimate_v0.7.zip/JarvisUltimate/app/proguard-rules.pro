# Release minify is disabled (see app/build.gradle.kts). Rules kept here for when it is enabled and tested.
-keep class com.avi.jarvis.** { *; }
-dontwarn org.osmdroid.**
