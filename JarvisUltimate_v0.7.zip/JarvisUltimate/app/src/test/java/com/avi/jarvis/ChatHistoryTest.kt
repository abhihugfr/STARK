package com.avi.jarvis
import org.junit.Assert.assertEquals
import org.junit.Test

class ChatHistoryTest {
    @Test fun dropsLeadingAssistantAndBlanks() {
        val r = ChatHistory.normalize(listOf("assistant" to "Namaste", "user" to " ", "user" to "hi"))
        assertEquals(listOf("user" to "hi"), r)
    }
    @Test fun mergesConsecutiveSameRole() {
        val r = ChatHistory.normalize(listOf("user" to "a", "user" to "b", "assistant" to "c", "user" to "d"))
        assertEquals(listOf("user" to "a\nb", "assistant" to "c", "user" to "d"), r)
    }
    @Test fun ignoresUnknownRoles() {
        assertEquals(listOf("user" to "x"), ChatHistory.normalize(listOf("error" to "boom", "user" to "x")))
    }
    @Test fun emptyStaysEmpty() { assertEquals(emptyList<Pair<String, String>>(), ChatHistory.normalize(emptyList())) }
    @Test fun trimsOldestTurnsButKeepsUserFirst() {
        val big = "x".repeat(60)
        val r = ChatHistory.normalize(listOf("user" to big, "assistant" to big, "user" to big, "assistant" to big, "user" to "last"), maxChars = 150)
        assertEquals("user", r.first().first); assertEquals("last", r.last().second)
        assertEquals(true, r.sumOf { it.second.length } <= 150 || r.size == 1)
    }
}
