package com.avi.jarvis
import org.junit.Assert.assertEquals
import org.junit.Test

class AutomationLogicTest {
    private val day = 86_400_000L
    private fun f(kind: String, v: Int, last: Long = 0, en: Boolean = true, now: Long = 10 * day, mod: Int = 600, bat: Int = 50, ch: Boolean = false) =
        AutomationLogic.shouldFire(kind, v, last, en, now, mod, 10 * day, bat, ch)

    @Test fun batteryFiresWhenLowAndNotCharging() { assertEquals(true, f("battery", 20, bat = 15)) }
    @Test fun batteryNotWhenCharging() { assertEquals(false, f("battery", 20, bat = 15, ch = true)) }
    @Test fun batteryCooldown() { assertEquals(false, f("battery", 20, bat = 15, last = 10 * day - 3_600_000L)) }
    @Test fun disabledNeverFires() { assertEquals(false, f("battery", 20, bat = 5, en = false)) }
    @Test fun dailyFiresOnceInWindow() {
        assertEquals(true, f("daily", 540, mod = 600))                         // 09:00 rule at 10:00, not yet run today
        assertEquals(false, f("daily", 540, mod = 600, last = 10 * day + 1))   // already ran today
        assertEquals(false, f("daily", 540, mod = 700))                        // more than 2 h late: skipped
        assertEquals(false, f("daily", 700, mod = 600))                        // not yet time
    }
    @Test fun unknownKind() { assertEquals(false, f("weird", 1)) }
}
