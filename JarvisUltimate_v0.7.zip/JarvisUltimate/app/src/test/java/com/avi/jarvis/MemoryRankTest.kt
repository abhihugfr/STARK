package com.avi.jarvis
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class MemoryRankTest {
    @Test fun smallListIsKeptWhole() { assertEquals(listOf("a b c", "d e f"), MemoryRank.pick(listOf("a b c", "d e f"), "x")) }
    @Test fun relevantAndRecentAreChosen() {
        val all = (1..40).map { "fact number $it about topic$it" }
        val r = MemoryRank.pick(all, "tell me about topic3", max = 12, recent = 8)
        assertTrue(r.contains("fact number 3 about topic3"))
        assertTrue(r.contains("fact number 40 about topic40"))
        assertTrue(r.size <= 12)
        assertEquals(r, all.filter { it in r })   // original order preserved
    }
    @Test fun searchIsCaseInsensitive() { assertEquals(listOf(1), MemoryRank.search(listOf("chai", "Mujhe CHOCOLATE pasand"), "chocolate")) }
    @Test fun blankSearchShowsAll() { assertEquals(listOf(0, 1), MemoryRank.search(listOf("a", "b"), "  ")) }
}
