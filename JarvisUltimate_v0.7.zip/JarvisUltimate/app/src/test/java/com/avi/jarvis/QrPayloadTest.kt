package com.avi.jarvis
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class QrPayloadTest {
    @Test fun acceptsValidPayload() { assertEquals("ABCDEFGH23", Cloud.codeFromQr("jarvis://pair/abcdefgh23")) }
    @Test fun rejectsForeignQr() { assertNull(Cloud.codeFromQr("https://evil.example/ABCDEFGH23")) }
    @Test fun rejectsWrongLengthOrAlphabet() {
        assertNull(Cloud.codeFromQr("jarvis://pair/ABC"))
        assertNull(Cloud.codeFromQr("jarvis://pair/ABCDEFGH0I"))   // 0 and I are not in the alphabet
    }
}
