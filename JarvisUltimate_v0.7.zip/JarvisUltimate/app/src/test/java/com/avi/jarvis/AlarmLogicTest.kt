package com.avi.jarvis
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.util.Calendar

class AlarmLogicTest {
    private fun at(h: Int, m: Int): Long = Calendar.getInstance().apply {
        set(2026, Calendar.NOVEMBER, 23, h, m, 0); set(Calendar.MILLISECOND, 0)
    }.timeInMillis

    @Test fun laterTodayStaysToday() {
        val r = AlarmLogic.nextAt(18, 30, at(14, 0))
        assertEquals(at(18, 30), r)
    }
    @Test fun passedTimeGoesToTomorrow() {
        val r = AlarmLogic.nextAt(6, 0, at(14, 0))
        assertEquals(at(6, 0) + 24 * 3_600_000L, r)
    }
    @Test fun sameMinuteGoesToTomorrow() {
        assertTrue(AlarmLogic.nextAt(14, 0, at(14, 0)) > at(14, 0))
    }
}
