package com.avi.jarvis
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class CalcTest {
    @Test fun basicWords() { assertEquals("27", Calc.answer("12 plus 5 times 3 minus 0")) }
    @Test fun precedenceAndParens() { assertEquals("17", Calc.answer("2+3*5")); assertEquals("25", Calc.answer("(2+3)*5")) }
    @Test fun prefixes() { assertEquals("5", Calc.answer("calculate (4+6)/2")); assertEquals("8", Calc.answer("what is 4 times 2?")) }
    @Test fun decimals() { assertEquals("0.3333", Calc.answer("1/3")); assertEquals("2.5", Calc.answer("5/2")) }
    @Test fun divideByZero() { assertEquals("Zero se divide nahi ho sakta.", Calc.answer("5/0")) }
    @Test fun notMath() { assertNull(Calc.answer("hello world")); assertNull(Calc.answer("12")); assertNull(Calc.answer("2 +")) }
    @Test fun noCodeInjection() { assertNull(Calc.answer("2+2; rm -rf")); assertNull(Calc.answer("system(1)+2")) }
}
