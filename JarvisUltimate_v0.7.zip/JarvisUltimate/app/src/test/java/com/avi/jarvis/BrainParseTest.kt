package com.avi.jarvis
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class BrainParseTest {
    @Test fun parsesTextBlocksAndSkipsOthers() {
        val json = """{"content":[{"type":"thinking","thinking":"x"},{"type":"text","text":"Namaste "},{"type":"text","text":"ji"}]}"""
        assertEquals(Ai.Ok("Namaste ji"), Brain.parse(json))
    }
    @Test fun hindiRoundTrip() {
        assertEquals(Ai.Ok("नमस्ते"), Brain.parse("""{"content":[{"type":"text","text":"नमस्ते"}]}"""))
    }
    @Test fun emptyContentIsError() { assertTrue(Brain.parse("""{"content":[]}""") is Ai.Err) }
    @Test fun garbageIsError() { assertTrue(Brain.parse("<html>502</html>") is Ai.Err) }
    @Test fun modelIdsAreCurrentAndUnique() {
        val ids = Brain.MODELS.map { it.second }
        assertEquals(ids.size, ids.toSet().size)
        assertTrue(ids.all { it.startsWith("claude-") })
    }
    @Test fun readsTokenUsage() {
        val r = Brain.parse("""{"content":[{"type":"text","text":"ok"}],"usage":{"input_tokens":12,"output_tokens":3}}""")
        assertEquals(Ai.Ok("ok", 12, 3), r)
    }
}
