package com.avi.jarvis
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.util.Calendar

class ReminderParserTest {
    private val now = Calendar.getInstance().apply { set(2026, Calendar.NOVEMBER, 23, 11, 0, 0); set(Calendar.MILLISECOND, 0) }.timeInMillis

    @Test fun relativeHinglish() {
        val p = ReminderParser.parse("10 minute baad chai yaad dilao", now)
        assertNotNull(p); assertEquals(now + 10 * 60_000L, p!!.first); assertEquals("chai", p.second)
    }
    @Test fun relativeEnglishHours() {
        val p = ReminderParser.parse("remind me in 2 hours to call mom", now)
        assertEquals(now + 2 * 3_600_000L, p!!.first); assertEquals("call mom", p.second)
    }
    @Test fun absolutePmToday() {
        val p = ReminderParser.parse("remind me at 8 pm to go to the gym", now)!!
        val c = Calendar.getInstance().apply { timeInMillis = p.first }
        assertEquals(20, c.get(Calendar.HOUR_OF_DAY)); assertEquals(23, c.get(Calendar.DAY_OF_MONTH))
        assertTrue(p.second.contains("gym"))
    }
    @Test fun pastTimeRollsToTomorrow() {
        val p = ReminderParser.parse("at 9 am wake up", now)!!
        val c = Calendar.getInstance().apply { timeInMillis = p.first }
        assertEquals(9, c.get(Calendar.HOUR_OF_DAY)); assertEquals(24, c.get(Calendar.DAY_OF_MONTH))
    }
    @Test fun noTimeIsNull() { assertNull(ReminderParser.parse("remind me to relax", now)) }
    @Test fun invalidHourIsNull() { assertNull(ReminderParser.parse("at 25 pm nothing", now)) }
}
