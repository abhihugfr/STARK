package com.avi.jarvis
import java.util.Calendar

/** Pure, unit-tested: next clock time (today if still ahead, otherwise tomorrow) for "alarm at h:m". */
object AlarmLogic {
    fun nextAt(h: Int, m: Int, now: Long): Long {
        val c = Calendar.getInstance()
        c.timeInMillis = now
        c.set(Calendar.HOUR_OF_DAY, h); c.set(Calendar.MINUTE, m); c.set(Calendar.SECOND, 0); c.set(Calendar.MILLISECOND, 0)
        if (c.timeInMillis <= now) c.add(Calendar.DAY_OF_YEAR, 1)
        return c.timeInMillis
    }
}
