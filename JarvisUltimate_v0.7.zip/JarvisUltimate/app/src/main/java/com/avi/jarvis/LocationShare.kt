package com.avi.jarvis
import android.Manifest
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Build
import android.os.Bundle
import android.os.IBinder
import android.os.Looper
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.google.firebase.firestore.FirebaseFirestore

/**
 * Visible foreground service that publishes this phone's location ONLY for pairings where the owner switched
 * "Share my live location" ON. Persistent notification with Stop. Auto-stops after 4 hours.
 * The other side can read it only if THEY have also switched sharing on (enforced in firestore.rules).
 */
class LocationShareService : Service() {
    private var lm: LocationManager? = null
    private var ids: List<String> = emptyList()
    private var loaded = false
    private var fixes = 0
    private val main = android.os.Handler(Looper.getMainLooper())

    private val listener = object : LocationListener {
        override fun onLocationChanged(l: Location) {
            if (System.currentTimeMillis() > Cloud.locUntil(this@LocationShareService)) { expire(); return }
            if (fixes++ % 20 == 0) refreshIds()
            if (loaded && ids.isEmpty()) { stopSelf(); return }
            ids.forEach { Cloud.pushPlace(it, l.latitude, l.longitude, l.accuracy.toDouble()) }
        }
        @Deprecated("Deprecated in Java")
        override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
        override fun onProviderEnabled(provider: String) {}
        override fun onProviderDisabled(provider: String) {}
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) { Cloud.stopAllSharing(this); stopSelf(); return START_NOT_STICKY }
        val fine = granted(this, Manifest.permission.ACCESS_FINE_LOCATION)
        val coarse = granted(this, Manifest.permission.ACCESS_COARSE_LOCATION)
        // startForegroundService() obliges us to call startForeground() quickly - even if we then stop right away, otherwise
        // Android kills the app ("did not then call startForeground"). On Android 14+ the location type throws without permission.
        try { startFg() } catch (e: Exception) { stopSelf(); return START_NOT_STICKY }
        if (!fine && !coarse) { stopSelf(); return START_NOT_STICKY }
        if (!Cloud.anyLocalSharing(this)) { stopSelf(); return START_NOT_STICKY }
        Cloud.beginSharing(this)
        running = true
        // Real timer: expiry must not depend on the phone moving (location callbacks only fire on movement).
        main.removeCallbacksAndMessages(null)
        main.postDelayed({ expire() }, maxOf(1000L, Cloud.locUntil(this) - System.currentTimeMillis()))
        val m = getSystemService(Context.LOCATION_SERVICE) as LocationManager
        lm = m
        refreshIds()
        try {
            m.removeUpdates(listener)
            if (fine && m.isProviderEnabled(LocationManager.GPS_PROVIDER))
                m.requestLocationUpdates(LocationManager.GPS_PROVIDER, 15_000L, 10f, listener, Looper.getMainLooper())
            if (m.isProviderEnabled(LocationManager.NETWORK_PROVIDER))
                m.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 15_000L, 10f, listener, Looper.getMainLooper())
        } catch (e: SecurityException) { stopSelf() }
        return START_NOT_STICKY
    }

    private fun expire() { Cloud.stopAllSharing(this); stopSelf() }

    private fun refreshIds() {
        val me = Cloud.uid ?: return
        FirebaseFirestore.getInstance().collection("pairings").whereArrayContains("members", me).get()
            .addOnSuccessListener { q ->
                ids = q.documents.filter { it.getString("status") == "active" && Cloud.localPerms(this, it.id).loc }.map { it.id }
                loaded = true
            }
    }

    private fun startFg() {
        Notifs.ensure(this)
        val stop = PendingIntent.getService(this, 2, Intent(this, LocationShareService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE)
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val n = NotificationCompat.Builder(this, Notifs.CH_WAKE)
            .setSmallIcon(android.R.drawable.ic_menu_mylocation)
            .setContentTitle("JARVIS: live location share ON")
            .setContentText("Paired device ko tumhari location dikh rahi hai. Stop dabake band karo.")
            .setOngoing(true).setContentIntent(open).addAction(0, "Stop", stop).build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(3, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION) else startForeground(3, n)
    }

    override fun onDestroy() {
        running = false
        main.removeCallbacksAndMessages(null)
        try { lm?.removeUpdates(listener) } catch (e: Exception) { }
        super.onDestroy()
    }

    companion object {
        const val ACTION_STOP = "com.avi.jarvis.STOP_LOC"
        @Volatile var running = false
        fun stop(ctx: Context) { ctx.stopService(Intent(ctx, LocationShareService::class.java)) }
        fun start(ctx: Context): Boolean {
            if (!granted(ctx, Manifest.permission.ACCESS_FINE_LOCATION) && !granted(ctx, Manifest.permission.ACCESS_COARSE_LOCATION)) return false
            return try {
                ContextCompat.startForegroundService(ctx, Intent(ctx, LocationShareService::class.java)); true
            } catch (e: Exception) { false }
        }
    }
}
