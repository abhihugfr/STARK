package com.avi.jarvis
import android.app.AlarmManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/**
 * Exact alarms for reminders/timers/alarms. setAlarmClock() needs no special permission, fires on time even in Doze and
 * wakes the phone. WorkManager (Reminders.kt) stays as a backup; whichever fires first delivers, the other sees the item
 * is gone and does nothing.
 */
object Alarms {
    fun set(ctx: Context, id: Long, text: String, at: Long) {
        try {
            val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            val pi = pending(ctx, id, text)
            val show = PendingIntent.getActivity(ctx, 0, Intent(ctx, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
            try { am.setAlarmClock(AlarmManager.AlarmClockInfo(at, show), pi) }
            catch (e: Exception) { am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi) }
        } catch (e: Exception) { /* WorkManager backup still delivers (possibly a few minutes late) */ }
    }

    fun cancel(ctx: Context, id: Long) {
        try { (ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager).cancel(pending(ctx, id, "")) } catch (e: Exception) { }
    }

    private fun pending(ctx: Context, id: Long, text: String): PendingIntent =
        PendingIntent.getBroadcast(ctx, (id % Int.MAX_VALUE).toInt(),
            Intent(ctx, AlarmReceiver::class.java).putExtra("id", id).putExtra("t", text),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
}

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        val id = intent.getLongExtra("id", -1L)
        val text = intent.getStringExtra("t") ?: "Reminder"
        val store = Stores.get(ctx, "reminders")
        if (id >= 0 && store.all().none { it.id == id }) return     // already delivered or cancelled
        Notifs.reminder(ctx, text, 2000 + (id % 1000).toInt())
        if (id >= 0) store.remove(id)
    }
}

/**
 * After reboot / app update: re-arm pending alarms and automations. Android 14 forbids starting a microphone service from
 * the background, so if the wake-word mic was ON we post a notification; one tap reopens JARVIS, which restarts the mic.
 */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        val a = intent.action
        if (a != Intent.ACTION_BOOT_COMPLETED && a != Intent.ACTION_MY_PACKAGE_REPLACED) return
        try {
            val now = System.currentTimeMillis()
            for (r in Stores.get(ctx, "reminders").all()) if (r.extra > now) Alarms.set(ctx, r.id, r.text, r.extra)
            Automation.schedule(ctx)
            if (Prefs.get(ctx).wakeOn)
                Notifs.action(ctx, "JARVIS mic band hai", "Background mein sunne ke liye tap karo.",
                    Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK), 1)
        } catch (e: Exception) { }
    }
}
