package com.avi.jarvis
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.BatteryManager
import android.os.Build
import android.provider.AlarmClock
import android.provider.Settings
import android.view.KeyEvent

object Phone {
    fun battery(ctx: Context): String {
        val i = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val l = i?.getIntExtra("level", -1) ?: -1
        val s = i?.getIntExtra("scale", 100) ?: 100
        val ch = i?.getIntExtra("status", -1) == BatteryManager.BATTERY_STATUS_CHARGING
        return "Battery ${if (l < 0 || s <= 0) 0 else l * 100 / s}%" + if (ch) " (charging)" else ""
    }

    fun online(ctx: Context): Boolean {
        val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val net = cm.activeNetwork ?: return false
        val caps = cm.getNetworkCapabilities(net) ?: return false
        return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }

    fun network(ctx: Context): String {
        val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val caps = cm.activeNetwork?.let { cm.getNetworkCapabilities(it) } ?: return "Offline: koi network nahi."
        return when {
            caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "Wi-Fi connected."
            caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "Mobile data connected."
            else -> "Network connected."
        }
    }

    fun appVersion(ctx: Context): String = try {
        ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName ?: "?"
    } catch (e: Exception) { "?" }

    fun deviceInfo(): String =
        "${Build.MANUFACTURER} ${Build.MODEL}, Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})"

    fun torch(ctx: Context, on: Boolean): String = try {
        val cm = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
        val id = cm.cameraIdList.firstOrNull {
            cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
        } ?: return "Is phone mein flashlight nahi mili."
        cm.setTorchMode(id, on)
        if (on) "Flashlight on." else "Flashlight off."
    } catch (e: Exception) { "Flashlight error: ${e.message}" }

    fun volume(ctx: Context, dir: Int): String {
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        am.adjustStreamVolume(AudioManager.STREAM_MUSIC,
            if (dir > 0) AudioManager.ADJUST_RAISE else AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI)
        return if (dir > 0) "Volume badha diya." else "Volume kam kar diya."
    }

    fun mute(ctx: Context): String {
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_MUTE, AudioManager.FLAG_SHOW_UI)
        return "Media volume mute."
    }

    fun media(ctx: Context, keyCode: Int, label: String): String {
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, keyCode))
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, keyCode))
        return "$label (kaam tabhi karega jab koi music/video app active ho)."
    }

    /**
     * bg=true (called from the wake-word service / automation): Android 10+ silently blocks starting screens from the
     * background, so besides trying we always post a notification whose tap performs it.
     */
    private fun launch(ctx: Context, i: Intent, bg: Boolean = false, what: String = "JARVIS"): Boolean {
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        if (bg) Notifs.action(ctx, "JARVIS: $what", "Tap karke kholo.", i, what.hashCode())
        return try { ctx.startActivity(i); true } catch (e: Exception) { bg }
    }
    private fun bgNote(bg: Boolean) = if (bg) " (screen par na aaye to notification tap karo)" else ""

    fun openApp(ctx: Context, name: String, bg: Boolean = false): String {
        val pm = ctx.packageManager
        val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val m = pm.queryIntentActivities(q, 0).firstOrNull { it.loadLabel(pm).toString().contains(name, true) }
            ?: return "'$name' naam ka app nahi mila."
        val l = pm.getLaunchIntentForPackage(m.activityInfo.packageName) ?: return "App open nahi ho paya."
        return if (launch(ctx, l, bg, "${m.loadLabel(pm)}")) "${m.loadLabel(pm)} khol raha hoon." + bgNote(bg) else "App open nahi ho paya."
    }

    fun alarm(ctx: Context, h: Int, m: Int, bg: Boolean = false): String {
        if (bg) {
            val at = AlarmLogic.nextAt(h, m, System.currentTimeMillis())
            Reminders.schedule(ctx, Notifs.LOUD + "Alarm %02d:%02d".format(h, m), at)
            return "Alarm %02d:%02d ke liye set kar diya (%s).".format(h, m, Reminders.fmt(at))
        }
        val i = Intent(AlarmClock.ACTION_SET_ALARM).putExtra(AlarmClock.EXTRA_HOUR, h)
            .putExtra(AlarmClock.EXTRA_MINUTES, m).putExtra(AlarmClock.EXTRA_MESSAGE, "JARVIS")
        return if (launch(ctx, i)) "Alarm %02d:%02d ke liye clock app khol diya, confirm kar lo.".format(h, m)
        else "Clock app nahi mila."
    }

    fun timer(ctx: Context, secs: Int, bg: Boolean = false): String {
        if (bg) {
            Reminders.schedule(ctx, Notifs.LOUD + "Timer khatam ($secs second)", System.currentTimeMillis() + secs * 1000L)
            return "Timer $secs second ka set kar diya."
        }
        val i = Intent(AlarmClock.ACTION_SET_TIMER).putExtra(AlarmClock.EXTRA_LENGTH, secs)
            .putExtra(AlarmClock.EXTRA_MESSAGE, "JARVIS").putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        return if (launch(ctx, i)) "Timer $secs second ka set kar diya." else "Clock app nahi mila."
    }

    fun dial(ctx: Context, number: String, bg: Boolean = false): String =
        if (launch(ctx, Intent(Intent.ACTION_DIAL, android.net.Uri.parse("tel:" + number)), bg, "Dialer $number"))
            "Dialer khol raha hoon (call tum khud dabaoge)." + bgNote(bg) else "Dialer nahi mila."

    fun batteryPct(ctx: Context): Int {
        val i = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val l = i?.getIntExtra("level", -1) ?: -1
        val s = i?.getIntExtra("scale", 100) ?: 100
        return if (l < 0 || s <= 0) 100 else l * 100 / s
    }

    fun charging(ctx: Context): Boolean {
        val st = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))?.getIntExtra("status", -1) ?: -1
        return st == BatteryManager.BATTERY_STATUS_CHARGING || st == BatteryManager.BATTERY_STATUS_FULL
    }

    fun settingsAction(t: String): String? = when {
        "wifi" in t || "wi-fi" in t -> Settings.ACTION_WIFI_SETTINGS
        "bluetooth" in t -> Settings.ACTION_BLUETOOTH_SETTINGS
        "display" in t || "brightness" in t -> Settings.ACTION_DISPLAY_SETTINGS
        "sound" in t -> Settings.ACTION_SOUND_SETTINGS
        "location" in t -> Settings.ACTION_LOCATION_SOURCE_SETTINGS
        "airplane" in t -> Settings.ACTION_AIRPLANE_MODE_SETTINGS
        "settings" in t -> Settings.ACTION_SETTINGS
        else -> null
    }

    fun openSettings(ctx: Context, t: String, bg: Boolean = false): String {
        val a = settingsAction(t) ?: return "Kaun si setting?"
        return if (launch(ctx, Intent(a), bg, "Settings")) "Settings khol raha hoon." + bgNote(bg) else "Ye setting is phone par nahi khuli."
    }

    fun share(ctx: Context, text: String, bg: Boolean = false): String {
        val send = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, text)
        return if (launch(ctx, Intent.createChooser(send, "JARVIS share"), bg, "Share")) "Share sheet khol raha hoon." + bgNote(bg) else "Share nahi ho paya."
    }

    /** True when Android may not freeze/kill JARVIS to save battery (needed for reliable background listening). */
    fun batteryUnrestricted(ctx: Context): Boolean = try {
        (ctx.getSystemService(Context.POWER_SERVICE) as android.os.PowerManager).isIgnoringBatteryOptimizations(ctx.packageName)
    } catch (e: Exception) { false }

    /** Opens Android's battery-optimization list (no extra permission needed); user picks JARVIS > Don't optimize. */
    fun openBatterySettings(ctx: Context) {
        if (!launch(ctx, Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)))
            launch(ctx, Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, android.net.Uri.parse("package:" + ctx.packageName)))
    }
}
