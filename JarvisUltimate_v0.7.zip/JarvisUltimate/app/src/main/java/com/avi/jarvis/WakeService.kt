package com.avi.jarvis
import android.Manifest
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.PowerManager
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.widget.Toast
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

object WakeState { var running by mutableStateOf(false) }

/**
 * Foreground "listen for JARVIS" service. Honest limits:
 *  - This is NOT a hardware/low-power wake-word engine (no Porcupine/openWakeWord model). It repeatedly starts Android's
 *    SpeechRecognizer and string-matches the transcript for "jarvis". Battery cost is real, hence the idle auto-off,
 *    low-battery stop and error back-off below.
 *  - The recognizer may beep between sessions and, on some devices, sends audio to Google's servers (we ask for offline first).
 *  - Only text containing the wake word is acted on; other speech is discarded, never stored.
 *  - Android blocks launching apps/screens from here; such commands answer with an explanation.
 *  - Runs in the background (foreground service + partial wake lock). Reboot/kill: Android forbids restarting a microphone
 *    service from the background, so it is restarted when the app is opened (or via the notification shown after boot).
 *  - Must be started while the app is visible (Android 12+ forbids starting a microphone foreground service from the background).
 */
class WakeService : Service() {
    private val main = Handler(Looper.getMainLooper())
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var sr: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    @Volatile private var ttsReady = false
    private var awaitingCommand = false
    private var stopped = false
    private var started = false
    /** A command is being processed/spoken: no recognizer may run (prevents overlapping sessions and mic/TTS feedback). */
    private var busy = false
    /** Bumped for every new recognizer; callbacks of older recognizers are ignored. */
    private var generation = 0
    private var afterSpeak: (() -> Unit)? = null
    private var lastActivity = System.currentTimeMillis()
    private var quietErrors = 0     // "nothing heard" results: normal, only slows the loop down
    private var hardErrors = 0      // real failures (audio, network, busy, client): too many in a row => give up
    private var preferOffline = true

    private var wl: PowerManager.WakeLock? = null

    private val restart = Runnable { listen() }
    private val speakGuard = Runnable { finishSpeak() }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) { Prefs.get(this).wakeOn = false; stopSelf(); return START_NOT_STICKY }
        // startForegroundService() obliges us to call startForeground() quickly, so do it first. On Android 14+ this throws
        // SecurityException when RECORD_AUDIO is not granted; never let that crash the app.
        try { startFg() } catch (e: Exception) {
            Toast.makeText(this, "Mic service start nahi ho payi (mic permission / Android restriction).", Toast.LENGTH_LONG).show()
            stopSelf(); return START_NOT_STICKY
        }
        if (started) return START_NOT_STICKY          // duplicate start: never create a second recognition loop
        if (!granted(this, Manifest.permission.RECORD_AUDIO)) { stopSelf(); return START_NOT_STICKY }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            Toast.makeText(this, "Is phone mein speech recognizer nahi hai.", Toast.LENGTH_LONG).show()
            stopSelf(); return START_NOT_STICKY
        }
        started = true
        // Keep the CPU awake while the screen is off, otherwise listening freezes in the background. Released in onDestroy.
        try {
            wl = (getSystemService(Context.POWER_SERVICE) as PowerManager)
                .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "jarvis:wake").apply { setReferenceCounted(false); acquire(12 * 3_600_000L) }
        } catch (e: Exception) { }
        tts = TextToSpeech(this) { status -> ttsReady = status == TextToSpeech.SUCCESS }.also { t ->
            t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {}
                override fun onDone(utteranceId: String?) { main.post { finishSpeak() } }
                @Deprecated("Deprecated in Java")
                override fun onError(utteranceId: String?) { main.post { finishSpeak() } }
            })
        }
        WakeState.running = true
        lastActivity = System.currentTimeMillis()
        listen()
        return START_NOT_STICKY
    }

    private fun startFg() {
        Notifs.ensure(this)
        val stop = PendingIntent.getService(this, 1,
            Intent(this, WakeService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE)
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val n = NotificationCompat.Builder(this, Notifs.CH_WAKE)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("JARVIS mic ON")
            .setContentText("Background mein sun raha hoon. 'JARVIS' bolo. Band karne ke liye Stop dabao.")
            .setOngoing(true).setContentIntent(open).addAction(0, "Stop", stop).build()
        if (Build.VERSION.SDK_INT >= 30) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        else startForeground(1, n)
    }

    private fun scheduleListen(delayMs: Long) {
        if (stopped) return
        main.removeCallbacks(restart)          // exactly one pending restart at any time
        main.postDelayed(restart, delayMs)
    }

    private fun destroyRecognizer() {
        generation++                            // late callbacks from the old recognizer are now ignored
        try { sr?.cancel() } catch (e: Exception) { }
        try { sr?.destroy() } catch (e: Exception) { }
        sr = null
    }

    private fun listen() {
        if (stopped || busy) return
        main.removeCallbacks(restart)
        val idle = Prefs.get(this).wakeIdleMin
        if (idle > 0 && System.currentTimeMillis() - lastActivity > idle * 60_000L) {
            Toast.makeText(this, "JARVIS mic $idle minute se idle tha, battery bachane ke liye band kiya.", Toast.LENGTH_LONG).show()
            stopSelf(); return
        }
        if (Phone.batteryPct(this) < 15 && !Phone.charging(this)) {
            Toast.makeText(this, "Battery 15% se kam hai, JARVIS mic band kiya.", Toast.LENGTH_LONG).show()
            stopSelf(); return
        }
        destroyRecognizer()
        val gen = generation
        val r = try { SpeechRecognizer.createSpeechRecognizer(this) } catch (e: Exception) { null }
        if (r == null) { failed(); return }
        sr = r
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
            override fun onError(error: Int) {
                if (stopped || busy || gen != generation) return
                awaitingCommand = false
                when (error) {
                    SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> {
                        Toast.makeText(this@WakeService, "Mic permission nahi hai, JARVIS mic band kiya.", Toast.LENGTH_LONG).show()
                        stopSelf(); return
                    }
                    SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> { quietErrors++; hardErrors = 0 }
                    SpeechRecognizer.ERROR_LANGUAGE_NOT_SUPPORTED, SpeechRecognizer.ERROR_LANGUAGE_UNAVAILABLE -> {
                        preferOffline = false; hardErrors++       // no offline pack: allow the online recognizer
                    }
                    else -> hardErrors++                          // audio, network, server, busy, client
                }
                if (hardErrors >= MAX_HARD_ERRORS) { gaveUp(); return }
                // Silence: slow down (less battery). Real failures: exponential back-off up to 15 s.
                val wait = if (hardErrors == 0) minOf(400L + quietErrors * 200L, 2500L)
                           else minOf(1000L shl minOf(hardErrors, 4), 15_000L)
                scheduleListen(wait)
            }
            override fun onResults(results: Bundle?) {
                if (stopped || busy || gen != generation) return
                val heard = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.trim().orEmpty()
                quietErrors = 0; hardErrors = 0
                if (awaitingCommand) {
                    awaitingCommand = false
                    if (heard.isBlank()) scheduleListen(200) else respond(heard)
                    return
                }
                val low = heard.lowercase()
                val end = WAKE.firstNotNullOfOrNull { w -> low.indexOf(w).takeIf { it >= 0 }?.plus(w.length) }
                if (end == null) { scheduleListen(200); return }
                lastActivity = System.currentTimeMillis()
                val cmd = heard.substring(minOf(end, heard.length)).trim(' ', ',', '.', '!')
                if (cmd.isBlank()) {
                    awaitingCommand = true
                    busy = true
                    say("Ji?") { busy = false; scheduleListen(100) }
                } else respond(cmd)
            }
        })
        try {
            r.startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                .putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
                .putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, preferOffline)
                .putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3))
        } catch (e: Exception) { failed() }
    }

    private fun failed() {
        hardErrors++
        if (hardErrors >= MAX_HARD_ERRORS) gaveUp() else scheduleListen(minOf(1000L shl minOf(hardErrors, 4), 15_000L))
    }

    private fun gaveUp() {
        Toast.makeText(this, "Mic/recognizer baar baar fail ho raha hai, JARVIS mic band kiya.", Toast.LENGTH_LONG).show()
        stopSelf()
    }

    private fun respond(text: String) {
        busy = true
        scope.launch {
            val reply = try {
                when (val r = Commands.process(this@WakeService, text, emptyList(), bg = true)) {
                    is Ai.Ok -> r.text
                    is Ai.Err -> r.msg
                }
            } catch (e: Exception) { "Kuch gadbad ho gayi: ${e.message}" }
            lastActivity = System.currentTimeMillis()
            say(reply) { busy = false; scheduleListen(100) }
        }
    }

    /** Speaks [text], then runs [then] exactly once - also when TTS is missing, not ready, fails or never reports back. */
    private fun say(text: String, then: () -> Unit) {
        val t = tts
        afterSpeak = then
        if (t == null || !ttsReady || !Speech.say(this, t, text)) { finishSpeak(); return }
        main.removeCallbacks(speakGuard)
        main.postDelayed(speakGuard, 25_000)    // watchdog: never wait forever for onDone
    }

    private fun finishSpeak() {
        main.removeCallbacks(speakGuard)
        val f = afterSpeak ?: return
        afterSpeak = null
        if (!stopped) f()
    }

    override fun onDestroy() {
        stopped = true
        main.removeCallbacksAndMessages(null)
        destroyRecognizer()
        tts?.stop(); tts?.shutdown(); tts = null
        scope.cancel()
        try { wl?.let { if (it.isHeld) it.release() } } catch (e: Exception) { }
        wl = null
        WakeState.running = false
        super.onDestroy()
    }

    companion object {
        const val ACTION_STOP = "com.avi.jarvis.STOP"
        private const val MAX_HARD_ERRORS = 8
        val WAKE = listOf("jarvis", "jarvish", "jarwis", "जार्विस", "जारविस", "जार्विश", "जर्विस")

        /** False when mic permission is missing or Android refuses the start (e.g. app not visible). */
        fun start(ctx: Context): Boolean {
            if (!granted(ctx, Manifest.permission.RECORD_AUDIO)) return false
            return try {
                ContextCompat.startForegroundService(ctx, Intent(ctx, WakeService::class.java))
                Prefs.get(ctx).wakeOn = true; true
            } catch (e: Exception) { false }
        }

        fun stop(ctx: Context) {
            Prefs.get(ctx).wakeOn = false
            ctx.stopService(Intent(ctx, WakeService::class.java)); WakeState.running = false
        }
    }
}
