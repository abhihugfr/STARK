package com.avi.jarvis
import android.content.Context
import android.view.KeyEvent
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object Commands {
    /** Local command first; otherwise cloud AI. bg=true means called from the wake-word service (no UI launches allowed). */
    suspend fun process(ctx: Context, text: String, history: List<Pair<String, String>> = emptyList(), bg: Boolean = false): Ai {
        handle(ctx, text, bg)?.let { return Ai.Ok(it) }
        // Voice replies (wake service) are capped and asked to be short: faster to generate and to speak.
        if (bg) return Brain.ask(ctx, history + ("user" to text), 300,
            Brain.systemPrompt(ctx, text) + "\nThis answer will be spoken aloud: reply in at most 2 short sentences.")
        return Brain.ask(ctx, history + ("user" to text))
    }

    fun handle(ctx: Context, raw: String, bg: Boolean): String? {
        val t = raw.lowercase().trim().trimEnd('.', '!', '?')
        val short = t.split(Regex("\\s+")).size <= 6
        fun has(vararg k: String) = k.any { it in t }
        val openCmd = t.startsWith("open ") || t.startsWith("kholo ") || t.endsWith(" kholo")
        val notes = Stores.get(ctx, "notes")
        val mem = Stores.get(ctx, "memories")

        return when {
            short && Calc.answer(t) != null -> Calc.answer(t)
            short && has("flip a coin", "coin flip", "sikka uchalo") -> if (kotlin.random.Random.nextBoolean()) "Heads" else "Tails"
            has("timer") && Regex("(\\d+)\\s*(second|sec|minute|min|hour|ghant)").containsMatchIn(t) -> {
                val m = Regex("(\\d+)\\s*(second|sec|minute|min|hour|ghant)").find(t)!!
                val n = m.groupValues[1].toInt()
                val secs = when { m.groupValues[2].startsWith("s") -> n; m.groupValues[2].startsWith("m") -> n * 60; else -> n * 3600 }
                Phone.timer(ctx, secs, bg)
            }
            Regex("^(call|dial)\\s+\\+?[0-9 ]{6,15}$").matches(t) -> Phone.dial(ctx, t.substringAfter(' ').replace(" ", ""), bg)
            has("remind", "yaad dila") -> {
                val p = Reminders.parse(raw)
                if (p != null) {
                    val it2 = Reminders.schedule(ctx, p.second, p.first)
                    "Theek hai, ${Reminders.fmt(it2.extra)} par yaad dilaunga: ${p.second}"
                } else if (t.startsWith("remind") || t.startsWith("yaad dila"))
                    "Time samajh nahi aaya. Aise bolo: '10 minute baad chai yaad dilao' ya 'remind me at 8 pm to call'."
                else null
            }
            has("yaad rakh", "remember that", "remember this") || t.startsWith("remember ") -> {
                val m = raw.replace(Regex("(?i)\\b(please|yaad rakhna|yaad rakho|yaad rakh|remember that|remember this|remember)\\b[:,]?"), " ").trim()
                if (m.isBlank()) "Kya yaad rakhoon?" else { mem.add(m); "Yaad rakh liya: $m" }
            }
            t.startsWith("note ") || t.startsWith("note:") -> {
                val n = raw.replace(Regex("(?i)^\\s*note( karo| kar lo)?\\s*[:,-]?\\s*"), "").trim()
                if (n.isBlank()) "Note mein kya likhoon?" else { notes.add(n); "Note save kar diya: $n" }
            }
            short && has("show notes", "mere notes", "notes dikhao", "my notes") -> {
                val l = notes.all().takeLast(5)
                if (l.isEmpty()) "Abhi koi note nahi hai." else "Aakhri notes:\n" + l.joinToString("\n") { "- " + it.text }
            }
            short && has("meri memories", "what do you remember", "kya yaad hai") -> {
                val l = mem.all().takeLast(5)
                if (l.isEmpty()) "Abhi kuch yaad rakhne ko nahi diya." else "Mujhe ye yaad hai:\n" + l.joinToString("\n") { "- " + it.text }
            }
            short && has("battery") -> Phone.battery(ctx)
            short && has("flashlight", "torch") -> Phone.torch(ctx, !has(" off", "band", "bund"))
            short && has("network status", "internet status", "wifi status", "net status", "online hoon") -> Phone.network(ctx)
            short && has("device info", "phone info") -> Phone.deviceInfo()
            short && has("what time", "time kya", "kitne baje", "current time", "samay kya") ->
                SimpleDateFormat("hh:mm a", Locale.getDefault()).format(Date())
            short && has("today's date", "what date", "aaj ki date", "tarikh kya", "date kya") ->
                SimpleDateFormat("EEEE, d MMMM yyyy", Locale.getDefault()).format(Date())
            short && has("volume up", "volume badha", "volume increase", "awaaz badha") -> Phone.volume(ctx, 1)
            short && has("volume down", "volume kam", "volume decrease", "awaaz kam") -> Phone.volume(ctx, -1)
            short && (t == "mute" || has("mute karo")) -> Phone.mute(ctx)
            short && has("play music", "music chalao", "gana chalao", "resume music") -> Phone.media(ctx, KeyEvent.KEYCODE_MEDIA_PLAY, "Play bheja")
            short && has("pause music", "music roko", "gana roko", "pause song") -> Phone.media(ctx, KeyEvent.KEYCODE_MEDIA_PAUSE, "Pause bheja")
            short && has("next song", "agla gana", "next track") -> Phone.media(ctx, KeyEvent.KEYCODE_MEDIA_NEXT, "Next bheja")
            short && has("previous song", "pichla gana", "previous track") -> Phone.media(ctx, KeyEvent.KEYCODE_MEDIA_PREVIOUS, "Previous bheja")
            short && (openCmd || has("settings")) && Phone.settingsAction(t) != null ->
                Phone.openSettings(ctx, t, bg)
            t.startsWith("share ") -> Phone.share(ctx, raw.trim().substring(6), bg)
            has("alarm") -> {
                val r = Regex("(\\d{1,2})(?::(\\d{2}))?\\s*(am|pm)?").find(t)
                if (r == null) null else {
                    var h = r.groupValues[1].toInt()
                    val m = r.groupValues[2].ifBlank { "0" }.toInt()
                    val ap = r.groupValues[3]
                    if (ap == "pm" && h < 12) h += 12
                    if (ap == "am" && h == 12) h = 0
                    if (h !in 0..23 || m !in 0..59) null else Phone.alarm(ctx, h, m, bg)
                }
            }
            openCmd -> {
                Phone.openApp(ctx, t.removePrefix("open ").removePrefix("kholo ").removeSuffix(" kholo").trim(), bg)
            }
            else -> null
        }
    }
}
