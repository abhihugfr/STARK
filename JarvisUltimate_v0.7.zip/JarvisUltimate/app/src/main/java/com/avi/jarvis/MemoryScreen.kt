package com.avi.jarvis
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun MemoryScreen() {
    var tab by remember { mutableIntStateOf(0) }
    Column(Modifier.fillMaxSize()) {
        TabRow(selectedTabIndex = tab, containerColor = Color.Black, contentColor = Cyan) {
            listOf("Memory", "Notes", "Reminders", "Auto").forEachIndexed { i, t ->
                Tab(selected = tab == i, onClick = { tab = i }, text = { Text(t) })
            }
        }
        when (tab) {
            0 -> ItemList("memories", "Kuch yaad rakhwao (jaise: mujhe chai pasand hai)",
                "Sirf wahi jo aap add karte ho. Ye AI ko context ke roop mein bheji jaati hai.")
            1 -> ItemList("notes", "Naya note", "Notes sirf is phone par rehte hain, AI ko nahi jaate.")
            2 -> RemindersTab()
            else -> AutomationTab()
        }
    }
}

@Composable
fun ItemList(kind: String, hint: String, info: String) {
    val ctx = LocalContext.current
    val store = remember(kind) { Stores.get(ctx, kind) }
    val rows = remember(kind) { mutableStateListOf<Item>().apply { addAll(store.all()) } }
    fun reload() { rows.clear(); rows.addAll(store.all()) }
    var input by remember { mutableStateOf("") }
    var editing by remember { mutableStateOf<Long?>(null) }
    var confirmClear by remember { mutableStateOf(false) }
    var query by remember { mutableStateOf("") }
    val shown = MemoryRank.search(rows.map { it.text }, query).map { rows[it] }

    Column(Modifier.fillMaxSize().padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(info, color = Color.Gray, fontSize = 12.sp)
        OutlinedTextField(query, { query = it }, Modifier.fillMaxWidth(), placeholder = { Text("Search...") }, singleLine = true)
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(input, { input = it }, Modifier.weight(1f), placeholder = { Text(hint) }, singleLine = true)
            Button(onClick = {
                val txt = input.trim()
                if (txt.isNotEmpty()) {
                    val e = editing
                    if (e != null) { store.update(e, txt); editing = null } else store.add(txt)
                    input = ""; reload()
                }
            }) { Text(if (editing != null) "Save" else "Add") }
        }
        if (rows.isEmpty()) Text("Abhi kuch nahi. Upar se add karo ya bolo/likho: 'yaad rakho ...' / 'note: ...'", color = Color.White)
        else if (shown.isEmpty()) Text("Koi match nahi mila.", color = Color.White)
        LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(shown, key = { it.id }) { it2 ->
                Glass(Modifier.fillMaxWidth()) {
                    Text(it2.text, color = Color.White)
                    Row {
                        TextButton(onClick = { editing = it2.id; input = it2.text }) { Text("Edit") }
                        TextButton(onClick = { store.remove(it2.id); if (editing == it2.id) { editing = null; input = "" }; reload() }) { Text("Delete") }
                    }
                }
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(enabled = rows.isNotEmpty(), onClick = {
                Phone.share(ctx, rows.joinToString("\n") { "- " + it.text })
            }) { Text("Export") }
            OutlinedButton(enabled = rows.isNotEmpty(), onClick = { confirmClear = true }) { Text("Delete all") }
        }
    }
    if (confirmClear) AlertDialog(
        onDismissRequest = { confirmClear = false },
        title = { Text("Sab delete karein?") },
        text = { Text("Ye wapas nahi aayega.") },
        confirmButton = { TextButton(onClick = { store.clear(); reload(); confirmClear = false }) { Text("Delete") } },
        dismissButton = { TextButton(onClick = { confirmClear = false }) { Text("Cancel") } })
}

@Composable
fun RemindersTab() {
    val ctx = LocalContext.current
    val store = remember { Stores.get(ctx, "reminders") }
    val rows = remember { mutableStateListOf<Item>().apply { addAll(store.all().sortedBy { it.extra }) } }
    fun reload() { rows.clear(); rows.addAll(store.all().sortedBy { it.extra }) }
    var input by remember { mutableStateOf("") }
    var msg by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("Aise likho: '10 minute baad chai', 'in 2 hours call mom', 'at 8 pm gym', '7 baje padhai'. " +
            "Android kabhi kabhi kuch minute late kar sakta hai.", color = Color.Gray, fontSize = 12.sp)
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(input, { input = it }, Modifier.weight(1f), placeholder = { Text("Naya reminder") }, singleLine = true)
            Button(onClick = {
                val p = Reminders.parse(input)
                if (p == null) msg = "Time samajh nahi aaya."
                else { Reminders.schedule(ctx, p.second, p.first); msg = "Set: ${Reminders.fmt(p.first)}"; input = ""; reload() }
            }) { Text("Add") }
        }
        if (msg.isNotBlank()) Text(msg, color = Cyan)
        if (rows.isEmpty()) Text("Koi pending reminder nahi.", color = Color.White)
        LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(rows, key = { it.id }) { r ->
                Glass(Modifier.fillMaxWidth()) {
                    Text(r.text, color = Color.White)
                    Text(Reminders.fmt(r.extra), color = Cyan, fontSize = 12.sp)
                    TextButton(onClick = { Reminders.cancel(ctx, r.id); reload() }) { Text("Cancel") }
                }
            }
        }
        OutlinedButton(onClick = { reload() }) { Text("Refresh") }
    }
}

@Composable
fun AutomationTab() {
    val ctx = LocalContext.current
    val rows = remember { mutableStateListOf<Rule>().apply { addAll(Automation.rules(ctx)) } }
    fun reload() { rows.clear(); rows.addAll(Automation.rules(ctx)) }
    var kind by remember { mutableStateOf("battery") }
    var value by remember { mutableStateOf("") }
    var cmd by remember { mutableStateOf("") }
    var msg by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("Rule: trigger + local command (battery, flashlight, volume, note: ..., etc). Sirf is phone par chalta hai, cloud AI ya remote nahi. " +
            "Check lagbhag har 15 minute hota hai.", color = Color.Gray, fontSize = 12.sp)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            if (kind == "battery") Button(onClick = { kind = "battery" }) { Text("Battery <= %") } else OutlinedButton(onClick = { kind = "battery" }) { Text("Battery <= %") }
            if (kind == "daily") Button(onClick = { kind = "daily" }) { Text("Roz is time") } else OutlinedButton(onClick = { kind = "daily" }) { Text("Roz is time") }
        }
        OutlinedTextField(value, { value = it }, Modifier.fillMaxWidth(), singleLine = true,
            label = { Text(if (kind == "battery") "Battery % (jaise 20)" else "Time 24h (jaise 21:30)") })
        OutlinedTextField(cmd, { cmd = it }, Modifier.fillMaxWidth(), singleLine = true, label = { Text("Command (jaise: battery, flashlight off)") })
        Button(onClick = {
            val v = if (kind == "battery") value.trim().toIntOrNull()?.takeIf { it in 1..99 }
                else value.trim().split(":").let { p -> val h = p.getOrNull(0)?.toIntOrNull(); val mi = p.getOrNull(1)?.toIntOrNull() ?: 0
                    if (h != null && h in 0..23 && mi in 0..59) h * 60 + mi else null }
            if (v == null || cmd.isBlank()) msg = "Value ya command sahi nahi hai."
            else { Automation.add(ctx, kind, v, cmd); value = ""; cmd = ""; msg = "Rule add ho gaya."; reload() }
        }) { Text("Add rule") }
        if (msg.isNotBlank()) Text(msg, color = Cyan)
        if (rows.isEmpty()) Text("Koi automation nahi.", color = Color.White)
        LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(rows, key = { it.id }) { r ->
                Glass(Modifier.fillMaxWidth()) {
                    Text(if (r.kind == "battery") "Jab battery <= ${r.value}%" else "Roz %02d:%02d".format(r.value / 60, r.value % 60), color = Cyan, fontSize = 12.sp)
                    Text("Chalao: ${r.cmd}", color = Color.White)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Switch(r.enabled, { on -> Automation.setEnabled(ctx, r, on); reload() })
                        Text(if (r.enabled) "ON" else "OFF", color = if (r.enabled) Cyan else Color.Gray, modifier = Modifier.padding(start = 8.dp))
                        TextButton(onClick = { Automation.remove(ctx, r.id); reload() }) { Text("Delete") }
                    }
                }
            }
        }
    }
}
