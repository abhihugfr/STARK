package com.avi.jarvis
import android.content.Context
import androidx.compose.runtime.mutableStateOf
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.SocketTimeoutException
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

sealed class Ai {
    data class Ok(val text: String, val inTokens: Int = 0, val outTokens: Int = 0) : Ai()
    /** [offline] = the request never reached the API (no network / timeout), as opposed to the API answering with an error. */
    data class Err(val msg: String, val offline: Boolean = false) : Ai()
}

enum class AiState { IDLE, CONNECTING, CONNECTED, OFFLINE, API_ERROR }

/** Truthful AI status: CONNECTED only after a real successful API answer; never assumed. */
object AiStatus {
    val state = mutableStateOf(AiState.IDLE)
    val detail = mutableStateOf("")
    fun label(s: AiState) = when (s) {
        AiState.IDLE -> "AI: not tested yet"
        AiState.CONNECTING -> "AI: connecting..."
        AiState.CONNECTED -> "AI: connected"
        AiState.OFFLINE -> "AI: offline"
        AiState.API_ERROR -> "AI: API error"
    }
}

object Brain {
    private const val ENDPOINT = "https://api.anthropic.com/v1/messages"
    val MODELS = listOf("Sonnet" to "claude-sonnet-5-5", "Haiku" to "claude-haiku-5-5", "Opus" to "claude-opus-5-5", "Fable" to "claude-fable-5-2")

    /** Persona + date + the memories the owner explicitly saved. */
    fun systemPrompt(ctx: Context, query: String = ""): String {
        val all = Stores.get(ctx, "memories").all().map { it.text }
        val mem = MemoryRank.pick(all, query)
        val now = SimpleDateFormat("EEEE, d MMMM yyyy, hh:mm a", Locale.getDefault()).format(Date())
        val sb = StringBuilder(Prefs.get(ctx).persona).append("\nCurrent date/time: ").append(now).append('.')
        if (mem.isNotEmpty()) {
            sb.append("\nThings the owner asked you to remember:\n")
            mem.forEach { sb.append("- ").append(it).append('\n') }
        }
        return sb.toString()
    }

    /** Public entry: runs the request, then records the true status and token usage. */
    suspend fun ask(ctx: Context, history: List<Pair<String, String>>, maxTokens: Int = 1000, system: String? = null): Ai {
        AiStatus.state.value = AiState.CONNECTING
        val r = askInner(ctx, history, maxTokens, system)
        when (r) {
            is Ai.Ok -> {
                AiStatus.state.value = AiState.CONNECTED; AiStatus.detail.value = ""
                if (r.inTokens + r.outTokens > 0) Prefs.get(ctx).addUsage(r.inTokens, r.outTokens)
            }
            is Ai.Err -> { AiStatus.state.value = if (r.offline) AiState.OFFLINE else AiState.API_ERROR; AiStatus.detail.value = r.msg }
        }
        return r
    }

    private suspend fun askInner(ctx: Context, history: List<Pair<String, String>>, maxTokens: Int, system: String?): Ai =
        withContext(Dispatchers.IO) {
            val p = Prefs.get(ctx)
            if (p.apiKey.isBlank()) return@withContext Ai.Err("Settings mein Anthropic API key daalo.")
            if (!Phone.online(ctx)) return@withContext Ai.Err(
                "Internet nahi hai, isliye cloud AI band hai. Notes, reminders, battery, flashlight jaise local commands chalte hain.", offline = true)
            val msgs = JSONArray()
            val clean = ChatHistory.normalize(history)
            if (clean.isEmpty()) return@withContext Ai.Err("Kuch poochha nahi gaya.")
            clean.forEach { msgs.put(JSONObject().put("role", it.first).put("content", it.second)) }
            val model = p.model.trim().ifBlank { MODELS.first().second }
            val body = JSONObject().put("model", model).put("max_tokens", maxTokens)
                .put("system", system ?: systemPrompt(ctx, clean.last().second)).put("messages", msgs).toString()
            var lastErr = "Unknown error"
            for (attempt in 0..2) {
                var c: HttpURLConnection? = null
                try {
                    c = URL(ENDPOINT).openConnection() as HttpURLConnection
                    c.requestMethod = "POST"; c.doOutput = true
                    c.connectTimeout = 15000; c.readTimeout = 60000
                    c.setRequestProperty("x-api-key", p.apiKey)
                    c.setRequestProperty("anthropic-version", "2023-06-01")
                    c.setRequestProperty("content-type", "application/json")
                    c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
                    val code = c.responseCode
                    val stream = if (code in 200..299) c.inputStream else c.errorStream
                    val txt = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
                    if (code in 200..299) return@withContext parse(txt)
                    val detail = try { JSONObject(txt).optJSONObject("error")?.optString("message") } catch (e: Exception) { null }
                        ?: txt.take(200)
                    when (code) {
                        401 -> return@withContext Ai.Err("API key galat ya expire hai (401). Settings mein check karo.")
                        403 -> return@withContext Ai.Err("Is key ko permission nahi hai (403): $detail")
                        404 -> return@withContext Ai.Err("Model nahi mila (404). Settings mein model naam check karo: $model")
                        400 -> return@withContext Ai.Err("Request galat (400): $detail")
                        408, 429, 500, 502, 503, 504, 529 -> {
                            lastErr = "Server busy ($code): $detail"
                            if (attempt < 2) delay(1500L * (attempt + 1))
                        }
                        else -> return@withContext Ai.Err("Error $code: $detail")
                    }
                } catch (e: SocketTimeoutException) {
                    lastErr = "Server ne time par jawab nahi diya."
                    if (attempt < 2) delay(1000)
                } catch (e: IOException) {
                    lastErr = "Network problem: ${e.message}"
                    if (attempt < 2) delay(1000)
                } finally {
                    c?.disconnect()
                }
            }
            Ai.Err(lastErr, offline = lastErr.startsWith("Network") || lastErr.startsWith("Server ne time"))
        }

    internal fun parse(txt: String): Ai = try {
        val arr = JSONObject(txt).getJSONArray("content")
        val sb = StringBuilder()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            if (o.optString("type") == "text") sb.append(o.optString("text"))
        }
        val u = JSONObject(txt).optJSONObject("usage")
        if (sb.isBlank()) Ai.Err("AI ne khaali jawab diya.")
        else Ai.Ok(sb.toString().trim(), u?.optInt("input_tokens", 0) ?: 0, u?.optInt("output_tokens", 0) ?: 0)
    } catch (e: Exception) { Ai.Err("Jawab samajh nahi aaya: ${e.message}") }
}
