package com.avi.jarvis

/** Pure, unit-tested decision: should this automation rule fire now? */
object AutomationLogic {
    private const val BATTERY_COOLDOWN_MS = 6 * 3_600_000L
    private const val DAILY_WINDOW_MIN = 120      // WorkManager is approximate: allow firing up to 2 h after the set time, once per day

    fun shouldFire(kind: String, value: Int, last: Long, enabled: Boolean, now: Long,
                   minuteOfDay: Int, startOfDay: Long, batteryPct: Int, charging: Boolean): Boolean {
        if (!enabled) return false
        return when (kind) {
            "battery" -> batteryPct <= value && !charging && now - last > BATTERY_COOLDOWN_MS
            "daily" -> minuteOfDay >= value && minuteOfDay - value < DAILY_WINDOW_MIN && last < startOfDay
            else -> false
        }
    }
}
