package com.avi.jarvis
import android.content.Context
import android.speech.tts.TextToSpeech
import java.util.Locale

object Speech {
    /** Returns true if the text was queued for speaking (false = TTS missing/not ready/failed, caller must not wait for it). */
    fun say(ctx: Context, tts: TextToSpeech?, text: String, utteranceId: String = "jarvis"): Boolean {
        if (tts == null || text.isBlank()) return false
        return try {
            val loc = if (text.any { it in '\u0900'..'\u097F' }) Locale.forLanguageTag("hi-IN") else Locale.forLanguageTag("en-IN")
            val r = tts.setLanguage(loc)
            if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) tts.setLanguage(Locale.getDefault())
            tts.setSpeechRate(Prefs.get(ctx).rate)
            tts.speak(text.take(500), TextToSpeech.QUEUE_FLUSH, null, utteranceId) == TextToSpeech.SUCCESS
        } catch (e: Exception) { false }
    }
}
