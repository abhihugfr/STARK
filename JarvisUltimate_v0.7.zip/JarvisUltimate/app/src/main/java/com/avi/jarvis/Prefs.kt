package com.avi.jarvis
import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

/** All settings live in Keystore-backed encrypted storage. Nothing secret is hardcoded or shipped in the APK. */
class Prefs private constructor(private val sp: SharedPreferences) {
    var apiKey: String
        get() = sp.getString("key", "") ?: ""
        set(v) { sp.edit().putString("key", v).apply() }
    var model: String
        get() = sp.getString("model", "claude-sonnet-5-5") ?: "claude-sonnet-5-5"
        set(v) { sp.edit().putString("model", v).apply() }
    var persona: String
        get() = sp.getString("persona", DEFAULT_PERSONA) ?: DEFAULT_PERSONA
        set(v) { sp.edit().putString("persona", v).apply() }
    /** Wake-word listener switches itself off after this many idle minutes (0 = never). Saves battery. */
    var wakeIdleMin: Int
        get() = sp.getInt("wakeIdle", 0)
        set(v) { sp.edit().putInt("wakeIdle", v).apply() }
    /** User wants the background listener ON: restarted when the app is opened, and offered again after a reboot. */
    var wakeOn: Boolean
        get() = sp.getBoolean("wakeOn", false)
        set(v) { sp.edit().putBoolean("wakeOn", v).apply() }
    var rate: Float
        get() = sp.getFloat("rate", 1f)
        set(v) { sp.edit().putFloat("rate", v).apply() }

    var tokensIn: Long
        get() = sp.getLong("tokIn", 0L)
        private set(v) { sp.edit().putLong("tokIn", v).apply() }
    var tokensOut: Long
        get() = sp.getLong("tokOut", 0L)
        private set(v) { sp.edit().putLong("tokOut", v).apply() }
    @Synchronized fun addUsage(i: Int, o: Int) { tokensIn += i; tokensOut += o }
    fun resetUsage() { sp.edit().putLong("tokIn", 0L).putLong("tokOut", 0L).apply() }

    companion object {
        const val DEFAULT_PERSONA = "You are JARVIS, the owner's private assistant. Reply briefly, in the language the owner uses (Hindi, English or Hinglish)."
        private const val FILE = "jarvis_secure"
        @Volatile private var inst: Prefs? = null

        fun get(ctx: Context): Prefs = inst ?: synchronized(this) {
            inst ?: Prefs(open(ctx.applicationContext)).also { inst = it }
        }

        private fun open(c: Context): SharedPreferences {
            fun make(): SharedPreferences = EncryptedSharedPreferences.create(
                c, FILE,
                MasterKey.Builder(c).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build(),
                EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM)
            return try { make() } catch (e: Exception) {
                // Keystore got reset (restore, OS bug): old ciphertext is unreadable, start clean.
                c.deleteSharedPreferences(FILE); make()
            }
        }
    }
}
