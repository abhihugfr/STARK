package com.avi.jarvis
import android.Manifest
import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

val ErrRed = Color(0xFFFF5252)

fun granted(ctx: Context, perm: String) =
    ContextCompat.checkSelfPermission(ctx, perm) == PackageManager.PERMISSION_GRANTED

@Composable
fun Glass(modifier: Modifier = Modifier, onClick: (() -> Unit)? = null, content: @Composable ColumnScope.() -> Unit) {
    val shape = RoundedCornerShape(14.dp)
    Column(
        modifier.background(Color(0x1400E5FF), shape)
            .border(BorderStroke(1.dp, Cyan.copy(alpha = .35f)), shape)
            .then(if (onClick != null) Modifier.clickable { onClick() } else Modifier)
            .padding(14.dp),
        content = content)
}

/** Truthful AI connection indicator (see AiStatus): green/cyan only after a real successful API answer. */
@Composable
fun AiStatusChip(modifier: Modifier = Modifier) {
    val ctx = LocalContext.current
    val s = AiStatus.state.value
    val online = Phone.online(ctx)
    val shown = if (!online && s != AiState.CONNECTING) AiState.OFFLINE else s
    val col = when (shown) { AiState.CONNECTED -> Cyan; AiState.CONNECTING -> Color.White; AiState.IDLE -> Color.Gray; else -> ErrRed }
    val dot = when (shown) { AiState.CONNECTED -> "●"; AiState.CONNECTING -> "◐"; AiState.IDLE -> "○"; else -> "▲" }
    Column(modifier) {
        Text("$dot ${AiStatus.label(shown)}", color = col, fontSize = 12.sp)
        if ((shown == AiState.API_ERROR || shown == AiState.OFFLINE) && AiStatus.detail.value.isNotBlank())
            Text(AiStatus.detail.value, color = Color.Gray, fontSize = 11.sp, maxLines = 2)
    }
}

@Composable
fun Dashboard(openChat: () -> Unit) {
    val ctx = LocalContext.current
    val inf = rememberInfiniteTransition(label = "core")
    val rot by inf.animateFloat(0f, 360f, infiniteRepeatable(tween(14000, easing = LinearEasing)), label = "rot")
    val rev by inf.animateFloat(360f, 0f, infiniteRepeatable(tween(9000, easing = LinearEasing)), label = "rev")
    val pulse by inf.animateFloat(.88f, 1f, infiniteRepeatable(tween(1800), RepeatMode.Reverse), label = "pulse")
    var time by remember { mutableStateOf("") }
    var batt by remember { mutableStateOf("") }
    var torch by remember { mutableStateOf(false) }
    var note by remember { mutableStateOf("") }
    LaunchedEffect(Unit) {
        while (true) {
            time = SimpleDateFormat("hh:mm a", Locale.getDefault()).format(Date())
            batt = Phone.battery(ctx); delay(1000)
        }
    }
    fun startWake() { note = if (WakeService.start(ctx)) "" else "Wake word start nahi ho paya." }
    val perms = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        if (granted(ctx, Manifest.permission.RECORD_AUDIO)) { startWake() } else { note = "Wake word ke liye mic permission chahiye." }
    }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally) {
        Text("J.A.R.V.I.S", color = Cyan, fontSize = 20.sp, fontWeight = FontWeight.Light, letterSpacing = 6.sp)
        Spacer(Modifier.height(18.dp))
        Box(Modifier.size(260.dp).clickable { openChat() }, contentAlignment = Alignment.Center) {
            Canvas(Modifier.fillMaxSize()) {
                val c = center; val r = size.minDimension / 2
                drawCircle(Cyan.copy(alpha = .10f * pulse), r * pulse)
                drawCircle(Cyan.copy(alpha = .5f), r * .98f, style = Stroke(2.dp.toPx()))
                val o1 = Offset(c.x - r * .86f, c.y - r * .86f); val s1 = Size(r * 1.72f, r * 1.72f)
                val o2 = Offset(c.x - r * .68f, c.y - r * .68f); val s2 = Size(r * 1.36f, r * 1.36f)
                rotate(rot, c) {
                    drawArc(Cyan, 0f, 70f, false, o1, s1, style = Stroke(7.dp.toPx(), cap = StrokeCap.Round))
                    drawArc(Cyan, 180f, 70f, false, o1, s1, style = Stroke(7.dp.toPx(), cap = StrokeCap.Round))
                }
                rotate(rev, c) {
                    drawArc(Blue, 40f, 120f, false, o2, s2, style = Stroke(4.dp.toPx(), cap = StrokeCap.Round))
                    drawArc(Blue, 220f, 120f, false, o2, s2, style = Stroke(4.dp.toPx(), cap = StrokeCap.Round))
                }
                drawCircle(Color(0xFF031A26), r * .5f)
                drawCircle(Cyan.copy(alpha = .8f), r * .5f, style = Stroke(1.5.dp.toPx()))
            }
            Text("JARVIS", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Medium, letterSpacing = 3.sp)
        }
        Spacer(Modifier.height(6.dp))
        Text(time, color = Color.White, fontSize = 44.sp, fontWeight = FontWeight.Thin)
        AiStatusChip()
        Spacer(Modifier.height(14.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Glass(Modifier.weight(1f)) { Text("Power", color = Cyan, fontSize = 12.sp); Text(batt, color = Color.White) }
            Glass(Modifier.weight(1f), onClick = { note = Phone.torch(ctx, !torch); torch = !torch }) {
                Text("Flashlight", color = Cyan, fontSize = 12.sp); Text(if (torch) "On" else "Off", color = Color.White)
            }
        }
        Spacer(Modifier.height(12.dp))
        Glass(Modifier.fillMaxWidth(), onClick = {
            if (WakeState.running) WakeService.stop(ctx) else {
                val need = mutableListOf<String>()
                if (!granted(ctx, Manifest.permission.RECORD_AUDIO)) need.add(Manifest.permission.RECORD_AUDIO)
                if (Build.VERSION.SDK_INT >= 33 && !granted(ctx, Manifest.permission.POST_NOTIFICATIONS)) need.add(Manifest.permission.POST_NOTIFICATIONS)
                if (need.isEmpty()) startWake() else perms.launch(need.toTypedArray())
            }
        }) {
            Text("Wake word", color = Cyan, fontSize = 12.sp)
            Text(if (WakeState.running) "Mic ON: 'JARVIS' bolo. Band karne ke liye tap karo." else "Off. Tap karke 'JARVIS' sunna shuru karo.", color = Color.White)
        }
        Spacer(Modifier.height(12.dp))
        Glass(Modifier.fillMaxWidth(), onClick = openChat) {
            Text(if (note.isBlank()) "Tap the core to talk to JARVIS" else note, color = Color.White)
        }
    }
}

data class Msg(val role: String, val text: String)

@Composable
fun ChatScreen() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val store = remember { Stores.get(ctx, "chat") }
    val msgs = remember {
        mutableStateListOf<Msg>().apply {
            val old = store.all().takeLast(100)
            if (old.isEmpty()) add(Msg("assistant", "Namaste, main JARVIS hoon. Bolo ya likho."))
            else addAll(old.map { Msg(if (it.extra == 0L) "user" else "assistant", it.text) })
        }
    }
    var input by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var speak by remember { mutableStateOf(true) }
    val tts = remember { TextToSpeech(ctx) { } }
    DisposableEffect(Unit) { onDispose { tts.stop(); tts.shutdown() } }
    val list = rememberLazyListState()

    fun send(text: String) {
        val q = text.trim()
        if (q.isEmpty() || busy) return
        val history = msgs.filter { it.role != "error" }.takeLast(12).map { it.role to it.text }.dropWhile { it.first != "user" }
        msgs.add(Msg("user", q)); store.add(q, 0, 300); input = ""
        busy = true   // set before launching: two quick taps must not start two requests
        scope.launch {
            when (val r = Commands.process(ctx, q, history)) {
                is Ai.Ok -> { msgs.add(Msg("assistant", r.text)); store.add(r.text, 1, 300); if (speak) Speech.say(ctx, tts, r.text) }
                is Ai.Err -> msgs.add(Msg("error", r.msg))
            }
            busy = false
            list.animateScrollToItem(msgs.lastIndex)
        }
    }

    val mic = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        if (r.resultCode == Activity.RESULT_OK)
            r.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()?.let { send(it) }
    }
    Column(Modifier.fillMaxSize().padding(12.dp)) {
        AiStatusChip(Modifier.padding(bottom = 6.dp))
        LazyColumn(Modifier.weight(1f), state = list, verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(msgs) { m ->
                val me = m.role == "user"
                Row(Modifier.fillMaxWidth(), horizontalArrangement = if (me) Arrangement.End else Arrangement.Start) {
                    Glass(Modifier.widthIn(max = 300.dp)) {
                        Text(m.text, color = when (m.role) { "user" -> Cyan; "error" -> ErrRed; else -> Color.White })
                    }
                }
            }
            if (busy) item {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    CircularProgressIndicator(Modifier.size(18.dp), color = Cyan, strokeWidth = 2.dp)
                    Spacer(Modifier.width(8.dp)); Text("JARVIS soch raha hai...", color = Cyan.copy(alpha = .8f))
                }
            }
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(input, { input = it }, Modifier.weight(1f), placeholder = { Text("Message...") },
                singleLine = true, enabled = !busy)
            TextButton(enabled = !busy, onClick = {
                tts.stop()                       // voice interruption
                if (WakeState.running) WakeService.stop(ctx)   // mic can only serve one listener
                try {
                    mic.launch(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                        .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                        .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN"))
                } catch (e: ActivityNotFoundException) {
                    msgs.add(Msg("error", "Is phone mein speech recognizer (Google app) nahi hai."))
                }
            }) { Text("Mic") }
            Button(enabled = !busy, onClick = { send(input) }) { Text("Send") }
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Switch(speak, { speak = it; if (!it) tts.stop() }); Spacer(Modifier.width(8.dp)); Text("Voice reply", color = Color.White)
            Spacer(Modifier.weight(1f))
            TextButton(onClick = { store.clear(); msgs.clear(); msgs.add(Msg("assistant", "Chat history saaf kar di.")) }) { Text("Clear chat") }
        }
    }
}

@Composable
fun SettingsScreen() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val p = remember { Prefs.get(ctx) }
    var key by remember { mutableStateOf("") }
    var hasKey by remember { mutableStateOf(p.apiKey.isNotBlank()) }
    var model by remember { mutableStateOf(p.model) }
    var persona by remember { mutableStateOf(p.persona) }
    var rate by remember { mutableFloatStateOf(p.rate) }
    var idle by remember { mutableFloatStateOf(p.wakeIdleMin.toFloat()) }
    var status by remember { mutableStateOf("") }
    var testing by remember { mutableStateOf(false) }
    var micOk by remember { mutableStateOf(granted(ctx, Manifest.permission.RECORD_AUDIO)) }
    var notifOk by remember { mutableStateOf(Build.VERSION.SDK_INT < 33 || granted(ctx, Manifest.permission.POST_NOTIFICATIONS)) }
    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        micOk = granted(ctx, Manifest.permission.RECORD_AUDIO)
        notifOk = Build.VERSION.SDK_INT < 33 || granted(ctx, Manifest.permission.POST_NOTIFICATIONS)
    }
    fun save() {
        if (key.isNotBlank()) { p.apiKey = key.trim(); key = ""; hasKey = true }
        p.model = model.trim(); p.persona = persona; p.rate = rate; p.wakeIdleMin = idle.toInt()
    }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("AI settings", color = Cyan, fontSize = 20.sp)
        OutlinedTextField(key, { key = it }, Modifier.fillMaxWidth(),
            label = { Text(if (hasKey) "API key saved (hidden). Naya daalo to replace hogi" else "Anthropic API key") },
            visualTransformation = PasswordVisualTransformation(), singleLine = true)
        OutlinedTextField(model, { model = it }, Modifier.fillMaxWidth(), label = { Text("Model") }, singleLine = true)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Brain.MODELS.forEach { (label, id) -> OutlinedButton(onClick = { model = id }) { Text(label) } }
        }
        OutlinedTextField(persona, { persona = it }, Modifier.fillMaxWidth(), label = { Text("Personality") })
        Text("Voice speed: ${"%.1f".format(rate)}x", color = Color.White)
        Slider(value = rate, onValueChange = { rate = it }, valueRange = 0.5f..1.5f)
        Text(if (idle.toInt() == 0) "Wake mic auto-off: kabhi nahi" else "Wake mic auto-off: ${idle.toInt()} minute idle ke baad", color = Color.White)
        Slider(value = idle, onValueChange = { idle = (it / 5f).toInt() * 5f }, valueRange = 0f..120f)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { save(); status = "Saved." }) { Text("Save") }
            OutlinedButton(enabled = !testing, onClick = {
                save()
                scope.launch {
                    testing = true; status = "Testing..."
                    status = when (val r = Brain.ask(ctx, listOf("user" to "Reply with the single word: OK"), 20)) {
                        is Ai.Ok -> "Connection OK (${p.model})."
                        is Ai.Err -> r.msg
                    }
                    testing = false
                }
            }) { Text("Test connection") }
            OutlinedButton(onClick = { p.apiKey = ""; hasKey = false; status = "Key hata di." }) { Text("Clear key") }
        }
        if (status.isNotBlank()) Text(status, color = if (status.startsWith("Connection OK") || status == "Saved.") Cyan else Color.White)
        Text("API key sirf is phone ke encrypted storage mein hai, APK mein nahi.", color = Color.Gray, fontSize = 12.sp)

        AiStatusChip()
        var usageTick by remember { mutableIntStateOf(0) }
        Text("Token usage (is phone par, jo API ne report kiya): in ${p.tokensIn + 0 * usageTick} / out ${p.tokensOut}", color = Color.Gray, fontSize = 12.sp)
        TextButton(onClick = { p.resetUsage(); usageTick++ }) { Text("Reset usage counter") }

        Spacer(Modifier.height(8.dp))
        Text("Permissions", color = Cyan, fontSize = 20.sp)
        Glass(Modifier.fillMaxWidth()) {
            Text("Microphone: ${if (micOk) "allowed" else "not allowed"}", color = Color.White)
            Text("Notifications: ${if (notifOk) "allowed" else "not allowed"}", color = Color.White)
            Text("Wake word mic: ${if (WakeState.running) "ON" else "off"}", color = Color.White)
            Spacer(Modifier.height(6.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = {
                    val need = mutableListOf<String>()
                    if (!micOk) need.add(Manifest.permission.RECORD_AUDIO)
                    if (!notifOk && Build.VERSION.SDK_INT >= 33) need.add(Manifest.permission.POST_NOTIFICATIONS)
                    if (need.isNotEmpty()) permLauncher.launch(need.toTypedArray())
                }) { Text("Request") }
                OutlinedButton(onClick = {
                    ctx.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + ctx.packageName)))
                }) { Text("App settings") }
                if (WakeState.running) OutlinedButton(onClick = { WakeService.stop(ctx) }) { Text("Mic off") }
            }
            Spacer(Modifier.height(6.dp))
            Text("Battery: ${if (Phone.batteryUnrestricted(ctx)) "unrestricted (background OK)" else "optimized (background mein band ho sakta hai)"}", color = Color.White)
            OutlinedButton(onClick = { Phone.openBatterySettings(ctx) }) { Text("Background fix: Battery unrestricted") }
        }
        Spacer(Modifier.height(8.dp))
        Text("Privacy", color = Cyan, fontSize = 20.sp)
        Glass(Modifier.fillMaxWidth()) {
            Text("• API key: sirf is phone ke encrypted storage mein. Aapke messages seedhe Anthropic API ko jaate hain (HTTPS).\n" +
                "• Memories/notes/chat: sirf is phone par. AI ko sirf wahi memories jaati hain jo relevant ya recent hon.\n" +
                "• Wake word: abhi Android ka SpeechRecognizer chalta hai (asli wake-word engine nahi). Recognizer kuch phones par audio Google ke server ko bhej sakta hai. Sirf 'jarvis' wali baat par action hota hai, audio store nahi hota.\n" +
                "• Connected Mode: Firebase (Google) par login, pairing, messages. Transit mein encrypted (TLS), end-to-end encrypted NAHI. AI-to-AI sawaal bhi isi tarah.\n" +
                "• Location: sirf jab aap sharing ON karo, dono taraf ki marzi se, 4 ghante mein auto-off, notification ke saath.\n" +
                "• Koi analytics, ads ya tracker nahi.", color = Color.White, fontSize = 13.sp)
        }
        Spacer(Modifier.height(8.dp))
        Text("About", color = Cyan, fontSize = 20.sp)
        Text("JARVIS v${Phone.appVersion(ctx)} | ${Phone.deviceInfo()}\nFirebase: ${if (Cloud.configured(ctx)) "configured" else "not configured (google-services.json missing)"}\nInternet: ${if (Phone.online(ctx)) "online" else "offline"}",
            color = Color.White)
    }
}
