package com.avi.jarvis
import android.content.Context
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.Worker
import androidx.work.WorkerParameters
import org.json.JSONObject
import java.util.Calendar
import java.util.concurrent.TimeUnit

data class Rule(val id: Long, val kind: String, val value: Int, val cmd: String, val last: Long, val enabled: Boolean = true)

/**
 * Local automations. Trigger kinds: "battery" (battery <= value %, not charging) and "daily" (value = minutes after midnight).
 * Action = any local JARVIS command (never cloud AI, never remote). Result is posted as a notification.
 * Checked by WorkManager about every 15 minutes, so times are approximate (Android may delay periodic work).
 */
object Automation {
    private const val STORE = "automations"

    private fun parse(i: Item): Rule? = try {
        val o = JSONObject(i.text); Rule(i.id, o.getString("k"), o.getInt("v"), o.getString("c"), o.optLong("l"), o.optBoolean("e", true))
    } catch (e: Exception) { null }

    private fun json(kind: String, v: Int, cmd: String, last: Long, enabled: Boolean = true) =
        JSONObject().put("k", kind).put("v", v).put("c", cmd).put("l", last).put("e", enabled).toString()

    fun setEnabled(ctx: Context, r: Rule, on: Boolean) {
        Stores.get(ctx, STORE).update(r.id, json(r.kind, r.value, r.cmd, r.last, on))
    }

    fun rules(ctx: Context): List<Rule> = Stores.get(ctx, STORE).all().mapNotNull { parse(it) }

    fun add(ctx: Context, kind: String, value: Int, cmd: String) {
        Stores.get(ctx, STORE).add(json(kind, value, cmd.trim(), 0L), 0, 50)
        schedule(ctx)
    }

    fun remove(ctx: Context, id: Long) { Stores.get(ctx, STORE).remove(id); schedule(ctx) }

    fun schedule(ctx: Context) {
        val wm = WorkManager.getInstance(ctx.applicationContext)
        if (rules(ctx).isEmpty()) { wm.cancelUniqueWork("automation_tick"); return }
        wm.enqueueUniquePeriodicWork("automation_tick", ExistingPeriodicWorkPolicy.UPDATE,
            PeriodicWorkRequestBuilder<AutomationWorker>(15, TimeUnit.MINUTES).build())
    }

    fun run(ctx: Context) {
        val now = System.currentTimeMillis()
        val cal = Calendar.getInstance()
        val minuteOfDay = cal.get(Calendar.HOUR_OF_DAY) * 60 + cal.get(Calendar.MINUTE)
        val startOfDay = (cal.clone() as Calendar).apply {
            set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
        }.timeInMillis
        for (r in rules(ctx)) {
            val fire = AutomationLogic.shouldFire(r.kind, r.value, r.last, r.enabled, now, minuteOfDay, startOfDay,
                Phone.batteryPct(ctx), Phone.charging(ctx))
            if (!fire) continue
            val out = try { Commands.handle(ctx, r.cmd, true) } catch (e: Exception) { null }
            Notifs.connected(ctx, "JARVIS automation", out ?: "'${r.cmd}' local command nahi samajh aaya.", r.id.hashCode())
            Stores.get(ctx, STORE).update(r.id, json(r.kind, r.value, r.cmd, now, r.enabled))
        }
    }
}

class AutomationWorker(ctx: Context, p: WorkerParameters) : Worker(ctx, p) {
    override fun doWork(): Result { Automation.run(applicationContext); return Result.success() }
}
