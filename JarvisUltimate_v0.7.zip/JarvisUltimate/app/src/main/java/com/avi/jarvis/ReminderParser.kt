package com.avi.jarvis
import java.util.Calendar

/** Pure (Android-free, unit-tested) natural-language reminder time parser. */
object ReminderParser {
    private val REL = Regex("(\\d+)\\s*(seconds?|secs?|minutes?|mins?|hours?|hrs?|ghant[ae]y?|days?|din)")
    private val ABS = Regex("(?:at\\s*)?(\\d{1,2})(?::(\\d{2}))?\\s*(am|pm|baje)")

    /** "10 minute baad chai", "in 2 hours call mom", "at 8 pm gym", "7 baje padhai". Returns (triggerAt, task). */
    fun parse(raw: String, now: Long = System.currentTimeMillis()): Pair<Long, String>? {
        val t = raw.lowercase()
        val at: Long
        val matched: String
        val rel = REL.find(t)
        if (rel != null) {
            val n = rel.groupValues[1].toLong()
            val u = rel.groupValues[2]
            val ms = when {
                u.startsWith("sec") -> n * 1000
                u.startsWith("min") -> n * 60_000
                u.startsWith("h") || u.startsWith("ghant") -> n * 3_600_000
                else -> n * 86_400_000
            }
            at = now + ms; matched = rel.value
        } else {
            val ab = ABS.find(t) ?: return null
            val hh0 = ab.groupValues[1].toInt()
            val mm = ab.groupValues[2].ifBlank { "0" }.toInt()
            val s = ab.groupValues[3]
            var hh = hh0
            if (s == "pm" && hh < 12) hh += 12
            if (s == "am" && hh == 12) hh = 0
            if (hh > 23 || mm > 59) return null
            val cal = Calendar.getInstance().apply {
                set(Calendar.HOUR_OF_DAY, hh); set(Calendar.MINUTE, mm); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
            }
            if (cal.timeInMillis <= now && s == "baje" && hh < 12) cal.add(Calendar.HOUR_OF_DAY, 12)
            if (cal.timeInMillis <= now) cal.add(Calendar.DAY_OF_YEAR, 1)
            at = cal.timeInMillis; matched = ab.value
        }
        var task = raw.replace(Regex(Regex.escape(matched), RegexOption.IGNORE_CASE), " ").trim()
        task = task.replace(Regex("(?i)^((please|remind me|remind|reminder|set a reminder|set reminder|yaad dilao|yaad dilana|yaad dila|mujhe|in|at|baad|mein|to|ko|about|that)\\b[\\s,:-]*)+"), "")
        task = task.replace(Regex("(?i)([\\s,]*(yaad dilao|yaad dilana|yaad dila do|yaad dila|remind me|baad|mein|please))+$"), "").trim()
        return at to task.ifBlank { "Reminder" }
    }
}
