package com.avi.jarvis

/** Pure, unit-tested: choose which saved memories are sent to the AI (relevant ones + the most recent), never all of them blindly. */
object MemoryRank {
    private fun words(s: String) = s.lowercase().split(Regex("[^\\p{L}\\p{N}]+")).filter { it.length >= 3 }.toSet()

    fun pick(all: List<String>, query: String, max: Int = 20, recent: Int = 8): List<String> {
        if (all.size <= max) return all
        val q = words(query)
        val scored = all.withIndex().map { (i, m) -> Triple(i, m, words(m).count { it in q }) }
        val keep = HashSet<Int>()
        scored.filter { it.third > 0 }.sortedByDescending { it.third }.take(max - recent).forEach { keep.add(it.first) }
        all.indices.toList().takeLast(recent).forEach { keep.add(it) }
        return all.filterIndexed { i, _ -> i in keep }
    }

    /** Case-insensitive substring search used by the Memory/Notes screens. */
    fun search(texts: List<String>, q: String): List<Int> =
        if (q.isBlank()) texts.indices.toList() else texts.indices.filter { texts[it].contains(q.trim(), ignoreCase = true) }
}
