package com.avi.jarvis
import android.content.Context
import android.os.Build
import com.google.firebase.FirebaseApp
import com.google.firebase.Timestamp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.firestore.Query
import com.google.firebase.firestore.SetOptions
import com.google.firebase.messaging.FirebaseMessaging
import kotlinx.coroutines.tasks.await
import java.security.SecureRandom
import java.util.Date

data class Pairing(val id: String, val other: String, val status: String, val requestedByMe: Boolean, val codeId: String, val label: String = "")
/** What *I* allow the paired device to do. Stored in Firestore (server-enforced) and mirrored locally (receiver-enforced). */
data class Perms(val ring: Boolean = false, val signals: Boolean = false, val ai: Boolean = false, val loc: Boolean = false)
data class CMsg(val id: String, val pid: String, val from: String, val to: String, val type: String, val body: String, val sentAt: Long, val readAt: Long?)
data class Place(val lat: Double, val lng: Double, val acc: Double, val at: Long)

/**
 * Connected Mode backend: Firebase email auth, one-time-code / QR pairing with explicit accept,
 * messages, signals, ring, AI relay, consented location, presence. Needs app/google-services.json and
 * firestore.rules deployed. Not exercised against a real Firebase project by the author (see README).
 */
object Cloud {
    fun configured(ctx: Context): Boolean = FirebaseApp.getApps(ctx).isNotEmpty()
    private val auth get() = FirebaseAuth.getInstance()
    private val db get() = FirebaseFirestore.getInstance()
    val uid: String? get() = try { auth.currentUser?.uid } catch (e: Exception) { null }
    val email: String? get() = try { auth.currentUser?.email } catch (e: Exception) { null }

    fun myLabel(): String = (email ?: "").substringBefore('@').take(24).ifBlank { "Device" }

    suspend fun signUp(email: String, pass: String) {
        auth.createUserWithEmailAndPassword(email.trim(), pass).await()
        saveProfile()
    }

    suspend fun signIn(email: String, pass: String) {
        auth.signInWithEmailAndPassword(email.trim(), pass).await()
        saveProfile()
    }

    suspend fun signOut() {
        val me = uid
        try {
            if (me != null) db.collection("users").document(me).update("fcmToken", FieldValue.delete()).await()
            FirebaseMessaging.getInstance().deleteToken().await()
        } catch (e: Exception) { /* best effort */ }
        auth.signOut()
    }

    private suspend fun saveProfile() {
        val me = uid ?: return
        db.collection("users").document(me).set(
            mapOf("email" to (email ?: ""), "device" to Build.MODEL, "updatedAt" to FieldValue.serverTimestamp()),
            SetOptions.merge()).await()
        try { storeToken(FirebaseMessaging.getInstance().token.await()) } catch (e: Exception) { /* FCM optional */ }
    }

    /** Saves this phone's FCM token so the Cloud Function can wake it. Only the owner can read it (rules). */
    fun storeToken(token: String) {
        val me = uid ?: return
        db.collection("users").document(me).set(mapOf("fcmToken" to token), SetOptions.merge())
    }

    /** Force a fresh connection (used by the Reconnect button). */
    suspend fun reconnect() { db.disableNetwork().await(); db.enableNetwork().await() }

    // ---------- pairing ----------
    private const val ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
    const val QR_PREFIX = "jarvis://pair/"

    /** 10 chars from a 32-symbol alphabet (~50 bits), valid 10 minutes, single use. */
    suspend fun createPairCode(): String {
        val me = uid ?: error("Pehle login karo.")
        val rnd = SecureRandom()
        val code = (1..10).map { ALPHABET[rnd.nextInt(ALPHABET.length)] }.joinToString("")
        db.collection("pairCodes").document(code).set(mapOf(
            "ownerUid" to me,
            "ownerLabel" to myLabel(),
            "expiresAt" to Timestamp(Date(System.currentTimeMillis() + 10 * 60_000L)),
            "used" to false)).await()
        return code
    }

    /** Accepts a raw code or a scanned QR payload. */
    fun codeFromQr(text: String): String? {
        val t = text.trim()
        if (!t.startsWith(QR_PREFIX)) return null
        val c = t.removePrefix(QR_PREFIX).uppercase()
        return if (c.length == 10 && c.all { it in ALPHABET }) c else null
    }

    suspend fun joinWithCode(raw: String) {
        val me = uid ?: error("Pehle login karo.")
        val code = (codeFromQr(raw) ?: raw.trim().uppercase())
        if (code.length != 10) error("Code 10 characters ka hota hai.")
        val snap = db.collection("pairCodes").document(code).get().await()
        if (!snap.exists()) error("Code galat hai ya expire ho gaya.")
        val owner = snap.getString("ownerUid") ?: error("Code invalid hai.")
        val ownerLabel = snap.getString("ownerLabel") ?: "Device"
        val exp = snap.getTimestamp("expiresAt")?.toDate()?.time ?: 0L
        if (snap.getBoolean("used") == true || exp < System.currentTimeMillis()) error("Code expire ya use ho chuka hai.")
        if (owner == me) error("Apna hi code khud use nahi kar sakte.")
        // No second pending/active pairing with the same device (the server also enforces this via links/).
        val mine = db.collection("pairings").whereArrayContains("members", me).get().await()
        if (mine.documents.any { d -> d.getString("status") != "revoked" && (d.get("members") as? List<*>)?.contains(owner) == true })
            error("Is device ke saath pairing pehle se hai (pending ya active).")
        val ids = listOf(owner, me).sorted()
        // The pairing document id IS the code: a code can create at most one pairing, ever (atomic single use).
        val batch = db.batch()
        batch.set(db.collection("pairings").document(code), mapOf(
            "members" to ids, "requestedBy" to me, "status" to "pending",
            "labels" to mapOf(owner to ownerLabel, me to myLabel()),
            "codeId" to code, "createdAt" to FieldValue.serverTimestamp()))
        batch.set(db.collection("links").document(ids[0] + "_" + ids[1]), mapOf("pid" to code, "members" to ids))
        try { batch.commit().await() } catch (e: FirebaseFirestoreException) {
            if (e.code == FirebaseFirestoreException.Code.PERMISSION_DENIED)
                error("Pairing nahi ban saki: code pehle use ho chuka hai, ya is device se pairing pehle se hai.")
            throw e
        }
    }

    fun toPairing(d: DocumentSnapshot, me: String): Pairing? {
        val members = (d.get("members") as? List<*>)?.filterIsInstance<String>() ?: return null
        val other = members.firstOrNull { it != me } ?: return null
        val label = ((d.get("labels") as? Map<*, *>)?.get(other) as? String) ?: other.take(6)
        return Pairing(d.id, other, d.getString("status") ?: "?", d.getString("requestedBy") == me, d.getString("codeId") ?: "", label)
    }

    /** Only the side that did NOT request can accept. Also burns the one-time code. */
    suspend fun accept(p: Pairing) {
        db.collection("pairings").document(p.id).update("status", "active").await()
        // Best effort: mark the code used (it may already be gone via TTL; single use is enforced by the pairing id anyway).
        try { db.collection("pairCodes").document(p.codeId).update("used", true).await() } catch (e: Exception) { }
    }

    suspend fun revoke(ctx: Context, p: Pairing) {
        // Stop sharing first (rules still allow own-doc delete); then revoke. After revoke nothing is readable.
        try { db.collection("pairings").document(p.id).collection("location").document(uid ?: "x").delete().await() } catch (e: Exception) { }
        val me = uid ?: error("Pehle login karo.")
        val ids = listOf(me, p.other).sorted()
        val batch = db.batch()
        batch.update(db.collection("pairings").document(p.id), "status", "revoked")
        batch.delete(db.collection("links").document(ids[0] + "_" + ids[1]))
        batch.commit().await()
        sp(ctx).edit().remove("${p.id}.ring").remove("${p.id}.sig").remove("${p.id}.ai").remove("${p.id}.loc").apply()
        if (!anyLocalSharing(ctx)) LocationShareService.stop(ctx)
    }

    // ---------- permissions (what I allow the other device to do) ----------
    private fun sp(ctx: Context) = ctx.applicationContext.getSharedPreferences("jarvis_perms", Context.MODE_PRIVATE)

    fun localPerms(ctx: Context, pid: String): Perms = sp(ctx).let {
        Perms(it.getBoolean("$pid.ring", false), it.getBoolean("$pid.sig", false), it.getBoolean("$pid.ai", false), it.getBoolean("$pid.loc", false))
    }

    fun setPerms(ctx: Context, pid: String, p: Perms) {
        val me = uid ?: return
        sp(ctx).edit().putBoolean("$pid.ring", p.ring).putBoolean("$pid.sig", p.signals)
            .putBoolean("$pid.ai", p.ai).putBoolean("$pid.loc", p.loc).apply()
        db.collection("pairings").document(pid).collection("perms").document(me).set(mapOf(
            "allowRing" to p.ring, "allowSignals" to p.signals, "allowAi" to p.ai, "shareLocation" to p.loc,
            "updatedAt" to FieldValue.serverTimestamp()))
            .addOnFailureListener { Link.error.value = it.message ?: "Permission save nahi hui" }
    }

    fun anyLocalSharing(ctx: Context): Boolean = sp(ctx).let { s -> s.all.keys.any { it.endsWith(".loc") && s.getBoolean(it, false) } }
    fun locUntil(ctx: Context): Long = sp(ctx).getLong("loc_until", 0L)
    /** Opens (or keeps) the 4-hour sharing window. */
    fun beginSharing(ctx: Context) {
        val s = sp(ctx)
        if (s.getLong("loc_until", 0L) < System.currentTimeMillis()) s.edit().putLong("loc_until", System.currentTimeMillis() + 4 * 60 * 60_000L).apply()
    }

    fun refreshToken() {
        try { FirebaseMessaging.getInstance().token.addOnSuccessListener { storeToken(it) } } catch (e: Exception) { }
    }

    fun listenPerms(pid: String, who: String, onData: (Perms) -> Unit): ListenerRegistration =
        db.collection("pairings").document(pid).collection("perms").document(who).addSnapshotListener { s, e ->
            if (e != null) return@addSnapshotListener
            onData(if (s != null && s.exists()) Perms(s.getBoolean("allowRing") == true, s.getBoolean("allowSignals") == true,
                s.getBoolean("allowAi") == true, s.getBoolean("shareLocation") == true) else Perms())
        }

    // ---------- messages ----------
    private val lastSent = HashMap<String, Long>()

    /** Client-side rate limit (the other phone is protected from spam / accidental repeats): ring 10 s, others 0.8 s. */
    private fun throttled(pid: String, type: String): Boolean = synchronized(lastSent) {
        val now = System.currentTimeMillis()
        val gap = if (type == "ring") 10_000L else 800L
        val k = "$pid/$type"
        if (now - (lastSent[k] ?: 0L) < gap) true else { lastSent[k] = now; false }
    }

    fun send(p: Pairing, type: String, body: String) {
        val me = uid ?: return
        if (throttled(p.id, type)) { Link.error.value = "Thoda ruko, bahut jaldi jaldi bhej rahe ho."; return }
        // No await on purpose: offline sends queue locally and go out on reconnect.
        db.collection("pairings").document(p.id).collection("messages").add(mapOf(
            "from" to me, "to" to p.other, "type" to type, "body" to body.take(1000),
            "sentAt" to FieldValue.serverTimestamp(), "readAt" to null))
            .addOnFailureListener { Link.error.value = friendly(it) }
    }

    fun friendly(e: Exception): String =
        if (e is FirebaseFirestoreException && e.code == FirebaseFirestoreException.Code.PERMISSION_DENIED)
            "Server ne mana kiya: permission nahi hai (dusre device ne ye allow nahi kiya, ya pairing active nahi)."
        else e.message ?: "Error"

    fun toMsg(d: DocumentSnapshot, pid: String): CMsg? {
        val from = d.getString("from") ?: return null
        val to = d.getString("to") ?: return null
        val at = d.getTimestamp("sentAt", DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)?.toDate()?.time ?: System.currentTimeMillis()
        return CMsg(d.id, pid, from, to, d.getString("type") ?: "text", d.getString("body") ?: "", at, d.getTimestamp("readAt", DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)?.toDate()?.time)
    }

    fun listenThread(pid: String, onData: (List<CMsg>) -> Unit): ListenerRegistration =
        db.collection("pairings").document(pid).collection("messages")
            .orderBy("sentAt", Query.Direction.DESCENDING).limit(100)
            .addSnapshotListener { snap, _ ->
                if (snap != null) onData(snap.documents.mapNotNull { toMsg(it, pid) }.reversed())
            }

    /** Ids already sent a read receipt in this process: a message is marked read once, never in a snapshot -> write -> snapshot loop. */
    private val marked = java.util.Collections.synchronizedSet(HashSet<String>())

    fun markRead(pid: String, msgs: List<CMsg>) { msgs.forEach { markReadId(pid, it.id) } }

    fun markReadId(pid: String, id: String) {
        if (!marked.add("$pid/$id")) return
        db.collection("pairings").document(pid).collection("messages").document(id).update("readAt", FieldValue.serverTimestamp())
            .addOnFailureListener { marked.remove("$pid/$id") }
    }

    // ---------- presence ----------
    fun beat(pid: String) {
        val me = uid ?: return
        db.collection("pairings").document(pid).collection("presence").document(me).set(mapOf("lastSeen" to FieldValue.serverTimestamp()))
    }

    fun listenPresence(pid: String, who: String, onData: (Long) -> Unit): ListenerRegistration =
        db.collection("pairings").document(pid).collection("presence").document(who).addSnapshotListener { s, _ ->
            s?.getTimestamp("lastSeen", DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)?.toDate()?.time?.let(onData)
        }

    // ---------- location (only ever written while I have explicitly switched sharing on) ----------
    fun pushPlace(pid: String, lat: Double, lng: Double, acc: Double) {
        val me = uid ?: return
        db.collection("pairings").document(pid).collection("location").document(me).set(mapOf(
            "lat" to lat, "lng" to lng, "acc" to acc, "updatedAt" to FieldValue.serverTimestamp()))
    }

    fun stopSharing(pid: String) {
        val me = uid ?: return
        db.collection("pairings").document(pid).collection("location").document(me).delete()
    }

    /** Switches location sharing off for every pairing (notification Stop button / expiry). */
    fun stopAllSharing(ctx: Context) {
        val prefs = sp(ctx)
        prefs.all.keys.filter { it.endsWith(".loc") && prefs.getBoolean(it, false) }.forEach { k ->
            val pid = k.removeSuffix(".loc")
            setPerms(ctx, pid, localPerms(ctx, pid).copy(loc = false))
            stopSharing(pid)
        }
        sp(ctx).edit().remove("loc_until").apply()
    }

    fun listenPlace(pid: String, who: String, onData: (Place?, String) -> Unit): ListenerRegistration =
        db.collection("pairings").document(pid).collection("location").document(who).addSnapshotListener { s, e ->
            if (e != null) { onData(null, "Location abhi visible nahi: dono phones par sharing ON honi chahiye."); return@addSnapshotListener }
            if (s == null || !s.exists()) { onData(null, "Abhi koi location share nahi ho rahi."); return@addSnapshotListener }
            val at = s.getTimestamp("updatedAt", DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)?.toDate()?.time ?: 0L
            onData(Place(s.getDouble("lat") ?: 0.0, s.getDouble("lng") ?: 0.0, s.getDouble("acc") ?: 0.0, at), "")
        }
}
