package com.avi.jarvis
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.viewinterop.AndroidView
import org.osmdroid.config.Configuration
import org.osmdroid.tileprovider.tilesource.TileSourceFactory
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.Marker
import java.io.File

/**
 * In-app OpenStreetMap view (osmdroid, free, no API key). Shown only when the user taps "Map dikhao":
 * tile requests go to OpenStreetMap's servers (they see the map area being viewed, not who you are).
 */
@Composable
fun OsmMap(lat: Double, lng: Double, modifier: Modifier = Modifier) {
    val ctx = LocalContext.current
    val view = remember {
        Configuration.getInstance().apply {
            setUserAgentValue(ctx.packageName)
            setOsmdroidBasePath(File(ctx.cacheDir, "osm"))
            setOsmdroidTileCache(File(ctx.cacheDir, "osm/tiles"))
        }
        MapView(ctx).apply {
            setTileSource(TileSourceFactory.MAPNIK)
            setMultiTouchControls(true)
            controller.setZoom(16.0)
        }
    }
    DisposableEffect(view) {
        view.onResume()
        onDispose { view.onPause(); view.onDetach() }
    }
    AndroidView(factory = { view }, modifier = modifier, update = { mv ->
        val pt = GeoPoint(lat, lng)
        mv.overlays.clear()
        val marker = Marker(mv)
        marker.position = pt
        marker.setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_BOTTOM)
        mv.overlays.add(marker)
        mv.controller.setCenter(pt)
        mv.invalidate()
    })
}
