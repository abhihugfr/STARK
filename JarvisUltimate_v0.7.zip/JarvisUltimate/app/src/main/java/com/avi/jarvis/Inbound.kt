package com.avi.jarvis
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.Ringtone
import android.media.RingtoneManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import androidx.core.app.NotificationManagerCompat

/** Handles one incoming message exactly once (live listener and FCM may both deliver it). */
object Inbound {
    private const val FRESH_MS = 3 * 60_000L
    private val main = Handler(Looper.getMainLooper())

    fun handle(ctx: Context, m: CMsg, label: String) {
        val seen = Stores.get(ctx, "seen")
        synchronized(this) {
            if (seen.all().any { it.text == m.id }) return
            seen.add(m.id, 0, 500)
        }
        val fresh = System.currentTimeMillis() - m.sentAt < FRESH_MS
        val perms = Cloud.localPerms(ctx, m.pid)
        when (m.type) {
            "text" -> Notifs.connected(ctx, label, m.body, m.id.hashCode())
            "signal" -> if (perms.signals) {
                buzz(ctx)
                Notifs.connected(ctx, "$label ka signal", m.body, m.id.hashCode())
            }
            "ring" -> if (perms.ring && fresh) RemoteRing.start(ctx, label)
                else if (perms.ring) Notifs.connected(ctx, "Missed ring", "$label ne ring kiya tha.", m.id.hashCode())
            "locreq" -> Notifs.connected(ctx, "$label ko tumhari location chahiye",
                "JARVIS > Connect mein sharing ON karna ya na karna tumhari marzi hai.", m.id.hashCode())
            "ai_q" -> if (perms.ai) {
                val req = AiReq(m.pid, m.id, label, m.body.take(500))
                if (!AiInbox.add(ctx, req)) return   // too many pending from this device: drop silently
                main.post { Link.aiInbox.add(req) }
                Notifs.connected(ctx, "$label ka JARVIS sawaal puch raha hai", "JARVIS > Connect mein dekho. Tumhari ijazat ke bina jawab nahi jayega.", m.id.hashCode())
            }
            "ai_a" -> Notifs.connected(ctx, "$label ke JARVIS ka jawab", m.body, m.id.hashCode())
        }
        if (m.type != "text" && m.type != "ai_a") Cloud.markReadId(m.pid, m.id)
    }

    private fun buzz(ctx: Context) {
        try {
            val v = ctx.getSystemService(Vibrator::class.java)
            v.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 200, 120, 200), -1))
        } catch (e: Exception) { }
    }
}

/** Remote ring: loud alarm-stream tone for at most 30 s, always with a visible notification and Stop button. */
object RemoteRing {
    private var tone: Ringtone? = null
    private val main = Handler(Looper.getMainLooper())

    fun start(ctx: Context, who: String) {
        val app = ctx.applicationContext
        main.post {
            stop(app)
            val uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM) ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE)
            val r = RingtoneManager.getRingtone(app, uri) ?: return@post
            r.audioAttributes = AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build()
            if (Build.VERSION.SDK_INT >= 28) r.isLooping = true
            r.play()
            tone = r
            Notifs.ringing(app, who)
            main.postDelayed({ stop(app) }, 30_000)
        }
    }

    fun stop(ctx: Context) {
        main.removeCallbacksAndMessages(null)
        try { tone?.stop() } catch (e: Exception) { }
        tone = null
        NotificationManagerCompat.from(ctx.applicationContext).cancel(Notifs.RING_ID)
    }
}

class RingStopReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) { RemoteRing.stop(context) }
}

/** Custom signal names, stored on this phone. */
object Signals {
    private val DEFAULTS = listOf("Thinking of you ❤", "Call me", "I'm safe", "Come online")
    fun all(ctx: Context): List<Item> {
        val s = Stores.get(ctx, "signals")
        val sp = ctx.applicationContext.getSharedPreferences("jarvis_perms", Context.MODE_PRIVATE)
        if (!sp.getBoolean("signals_seeded", false)) {
            DEFAULTS.forEach { s.add(it, 0, 50) }
            sp.edit().putBoolean("signals_seeded", true).apply()
        }
        return s.all()
    }
}
