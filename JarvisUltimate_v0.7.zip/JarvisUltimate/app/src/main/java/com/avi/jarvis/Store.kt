package com.avi.jarvis
import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/** extra: reminders = trigger time (ms); chat = 0 user / 1 assistant. */
data class Item(val id: Long, val text: String, val time: Long, val extra: Long = 0L)

/** Tiny JSON-file list in app-private storage. Names used: memories, notes, reminders, chat. */
class ListStore(ctx: Context, name: String) {
    private val file = File(ctx.applicationContext.filesDir, "$name.json")

    private fun read(): MutableList<Item> {
        if (!file.exists()) return mutableListOf()
        return try {
            val a = JSONArray(file.readText())
            MutableList(a.length()) { i ->
                val o = a.getJSONObject(i)
                Item(o.getLong("id"), o.getString("text"), o.optLong("time"), o.optLong("extra"))
            }
        } catch (e: Exception) { mutableListOf() }
    }

    private fun write(l: List<Item>) {
        val a = JSONArray()
        l.forEach { a.put(JSONObject().put("id", it.id).put("text", it.text).put("time", it.time).put("extra", it.extra)) }
        val tmp = File(file.path + ".tmp")
        tmp.writeText(a.toString())
        if (!tmp.renameTo(file)) { file.writeText(a.toString()); tmp.delete() }
    }

    fun all(): List<Item> = synchronized(LOCK) { read() }

    fun add(text: String, extra: Long = 0L, keep: Int = 1000): Item = synchronized(LOCK) {
        val l = read()
        val id = maxOf(System.currentTimeMillis(), (l.maxOfOrNull { it.id } ?: 0L) + 1)
        val item = Item(id, text, System.currentTimeMillis(), extra)
        l.add(item)
        write(if (l.size > keep) l.takeLast(keep) else l)
        item
    }

    fun update(id: Long, text: String) = synchronized(LOCK) {
        write(read().map { if (it.id == id) it.copy(text = text) else it })
    }

    fun remove(id: Long) = synchronized(LOCK) { write(read().filter { it.id != id }) }
    fun clear() = synchronized(LOCK) { write(emptyList()) }

    companion object { private val LOCK = Any() }
}

object Stores {
    fun get(ctx: Context, name: String) = ListStore(ctx, name)
}
