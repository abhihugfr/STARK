package com.avi.jarvis
import com.google.android.gms.tasks.Tasks
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage
import java.util.concurrent.TimeUnit

/**
 * Receives a data-only FCM wake-up {pid, mid, type} (sent by functions/index.js). The push carries NO message text:
 * we fetch the message from Firestore with our own login, so Google's push channel never sees content.
 * If the fetch fails (offline, revoked, signed out) we never ring; we show a neutral notification instead so nothing is silently lost.
 */
class JarvisMessagingService : FirebaseMessagingService() {
    override fun onNewToken(token: String) { Cloud.storeToken(token) }

    override fun onMessageReceived(message: RemoteMessage) {
        val pid = message.data["pid"] ?: return
        val mid = message.data["mid"] ?: return
        val type = message.data["type"] ?: ""
        val me = Cloud.uid ?: return
        val app = applicationContext
        try {
            val db = FirebaseFirestore.getInstance()
            val doc = Tasks.await(db.collection("pairings").document(pid).collection("messages").document(mid).get(), 10, TimeUnit.SECONDS)
            val m = Cloud.toMsg(doc, pid) ?: throw IllegalStateException("bad message")
            if (m.to != me) return
            val pd = Tasks.await(db.collection("pairings").document(pid).get(), 10, TimeUnit.SECONDS)
            if (pd.getString("status") != "active") return
            val label = ((pd.get("labels") as? Map<*, *>)?.get(m.from) as? String) ?: "Paired device"
            Inbound.handle(app, m, label)
        } catch (e: Exception) {
            val text = if (type == "ring") "Ring request aayi thi par verify nahi ho saki, isliye phone ring nahi hua."
                else "Naya item aaya hai. JARVIS kholo (network ya login check karo)."
            Notifs.connected(app, "JARVIS Connected", text, mid.hashCode())
        }
    }
}
