package com.avi.jarvis

/** Offline calculator: "12 plus 5 times 3", "calculate (4+6)/2". Only digits and + - * / ( ) are ever evaluated. */
object Calc {
    private val OK = Regex("^[0-9+\\-*/(). ]+$")

    fun answer(raw: String): String? {
        var s = raw.lowercase().trim().trimEnd('?', '.', '=', '!')
        for (p in listOf("calculate", "hisab karo", "what is", "what's", "kitna hota hai", "solve")) if (s.startsWith(p)) s = s.removePrefix(p).trim()
        s = s.replace("multiplied by", "*").replace("divided by", "/").replace("plus", "+").replace("minus", "-")
            .replace("times", "*").replace("into", "*").replace(" x ", "*")
        if (!OK.matches(s) || s.none { it.isDigit() } || s.none { it in "+-*/" }) return null
        return try {
            val p = P(s)
            val v = p.expr()
            p.ws()
            if (p.i != s.length) return null
            when {
                v.isNaN() || v.isInfinite() -> "Zero se divide nahi ho sakta."
                v == Math.rint(v) && Math.abs(v) < 1e15 -> v.toLong().toString()
                else -> "%.4f".format(v).trimEnd('0').trimEnd('.')
            }
        } catch (e: Exception) { null }
    }

    private class P(val s: String) {
        var i = 0
        fun ws() { while (i < s.length && s[i] == ' ') i++ }
        fun expr(): Double {
            var v = term()
            var go = true
            while (go) {
                ws()
                if (i < s.length && (s[i] == '+' || s[i] == '-')) { val o = s[i++]; val r = term(); v = if (o == '+') v + r else v - r } else go = false
            }
            return v
        }
        fun term(): Double {
            var v = factor()
            var go = true
            while (go) {
                ws()
                if (i < s.length && (s[i] == '*' || s[i] == '/')) { val o = s[i++]; val r = factor(); v = if (o == '*') v * r else v / r } else go = false
            }
            return v
        }
        fun factor(): Double {
            ws()
            if (i < s.length && s[i] == '-') { i++; return -factor() }
            if (i < s.length && s[i] == '(') {
                i++
                val v = expr()
                ws()
                if (i >= s.length || s[i] != ')') throw IllegalArgumentException("paren")
                i++
                return v
            }
            val st = i
            while (i < s.length && (s[i].isDigit() || s[i] == '.')) i++
            if (st == i) throw IllegalArgumentException("number")
            return s.substring(st, i).toDouble()
        }
    }
}
