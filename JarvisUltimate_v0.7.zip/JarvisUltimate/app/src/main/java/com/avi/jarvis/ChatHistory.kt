package com.avi.jarvis

/** Pure (Android-free, unit-tested) preparation of chat turns for the Anthropic Messages API. */
object ChatHistory {
    /**
     * The Messages API needs: first turn = user, non-empty text, roles alternating. Consecutive same-role turns
     * (e.g. after a failed request left two user turns) are merged; leading assistant turns and blanks are dropped.
     */
    fun normalize(history: List<Pair<String, String>>, maxChars: Int = 12_000): List<Pair<String, String>> {
        val out = mutableListOf<Pair<String, String>>()
        for ((role, text) in history) {
            if (role != "user" && role != "assistant") continue
            if (text.isBlank()) continue
            if (out.isEmpty() && role != "user") continue
            if (out.isNotEmpty() && out.last().first == role) out[out.lastIndex] = role to (out.last().second + "\n" + text)
            else out.add(role to text)
        }
        // Context management: drop the oldest turns until the conversation fits; it must still start with a user turn.
        while (out.size > 1 && out.sumOf { it.second.length } > maxChars) out.removeAt(0)
        while (out.isNotEmpty() && out.first().first != "user") out.removeAt(0)
        return out
    }
}
