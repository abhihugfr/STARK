package com.avi.jarvis
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.work.ExistingWorkPolicy
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.Worker
import androidx.work.WorkerParameters
import androidx.work.workDataOf
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit

object Notifs {
    const val CH_REM = "reminders"
    const val CH_WAKE = "wake"
    const val CH_CONN = "connected"
    const val CH_ALARM = "alarms"
    /** Text prefix marking an alarm/timer: delivered on the loud alarm channel instead of the normal reminder one. */
    const val LOUD = "\u23F0 "
    fun ensure(ctx: Context) {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        val alarmCh = NotificationChannel(CH_ALARM, "Alarms & timers", NotificationManager.IMPORTANCE_HIGH)
        alarmCh.setSound(android.media.RingtoneManager.getDefaultUri(android.media.RingtoneManager.TYPE_ALARM),
            android.media.AudioAttributes.Builder().setUsage(android.media.AudioAttributes.USAGE_ALARM)
                .setContentType(android.media.AudioAttributes.CONTENT_TYPE_SONIFICATION).build())
        alarmCh.enableVibration(true)
        nm.createNotificationChannel(alarmCh)
        nm.createNotificationChannel(NotificationChannel(CH_REM, "Reminders", NotificationManager.IMPORTANCE_HIGH))
        nm.createNotificationChannel(NotificationChannel(CH_WAKE, "Wake word (mic on)", NotificationManager.IMPORTANCE_LOW))
        nm.createNotificationChannel(NotificationChannel(CH_CONN, "Connected Mode", NotificationManager.IMPORTANCE_HIGH))
    }

    /** Message / signal / request from a paired device. Tapping opens the app. */
    fun connected(ctx: Context, title: String, text: String, id: Int) {
        ensure(ctx)
        val open = android.app.PendingIntent.getActivity(ctx, 0, android.content.Intent(ctx, MainActivity::class.java),
            android.app.PendingIntent.FLAG_IMMUTABLE or android.app.PendingIntent.FLAG_UPDATE_CURRENT)
        val n = NotificationCompat.Builder(ctx, CH_CONN)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle(title).setContentText(text).setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setContentIntent(open).setAutoCancel(true).setPriority(NotificationCompat.PRIORITY_HIGH).build()
        try { NotificationManagerCompat.from(ctx).notify(5000 + (id and 0xFFFF), n) } catch (e: SecurityException) { }
    }

    const val RING_ID = 4999
    fun ringing(ctx: Context, who: String) {
        ensure(ctx)
        val stop = android.app.PendingIntent.getBroadcast(ctx, 7, android.content.Intent(ctx, RingStopReceiver::class.java),
            android.app.PendingIntent.FLAG_IMMUTABLE)
        val n = NotificationCompat.Builder(ctx, CH_CONN)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle("$who is ringing your phone").setContentText("Tap Stop to silence.")
            .setOngoing(true).addAction(0, "Stop", stop).setContentIntent(stop).setPriority(NotificationCompat.PRIORITY_MAX).build()
        try { NotificationManagerCompat.from(ctx).notify(RING_ID, n) } catch (e: SecurityException) { }
    }
    /** Background command that Android only lets run with a screen (open app, settings...): one tap on this notification does it. */
    fun action(ctx: Context, title: String, text: String, intent: android.content.Intent, id: Int) {
        ensure(ctx)
        val pi = android.app.PendingIntent.getActivity(ctx, id, intent,
            android.app.PendingIntent.FLAG_IMMUTABLE or android.app.PendingIntent.FLAG_UPDATE_CURRENT)
        val n = NotificationCompat.Builder(ctx, CH_CONN)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle(title).setContentText(text)
            .setContentIntent(pi).setAutoCancel(true).setPriority(NotificationCompat.PRIORITY_HIGH).build()
        try { NotificationManagerCompat.from(ctx).notify(6000 + (id and 0xFFF), n) } catch (e: SecurityException) { }
    }

    fun reminder(ctx: Context, text: String, id: Int) {
        ensure(ctx)
        val loud = text.startsWith(LOUD)
        val n = NotificationCompat.Builder(ctx, if (loud) CH_ALARM else CH_REM)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle(if (loud) "JARVIS alarm" else "JARVIS reminder").setContentText(text)
            .setAutoCancel(true).setPriority(NotificationCompat.PRIORITY_HIGH).build()
        try { NotificationManagerCompat.from(ctx).notify(id, n) } catch (e: SecurityException) { /* notification permission denied */ }
    }
}

class ReminderWorker(ctx: Context, p: WorkerParameters) : Worker(ctx, p) {
    override fun doWork(): Result {
        val text = inputData.getString("t") ?: "Reminder"
        val id = inputData.getLong("id", -1L)
        // The exact alarm (Background.kt) may already have delivered it, or it was cancelled: then do nothing.
        if (id >= 0 && Stores.get(applicationContext, "reminders").all().none { it.id == id }) return Result.success()
        Notifs.reminder(applicationContext, text, 2000 + (id % 1000).toInt())
        if (id >= 0) Stores.get(applicationContext, "reminders").remove(id)
        return Result.success()
    }
}

/** Reminders use WorkManager: survive reboot, but Android may delay them a few minutes in Doze (not exact alarms). */
object Reminders {

    fun fmt(ms: Long): String = SimpleDateFormat("d MMM, hh:mm a", Locale.getDefault()).format(Date(ms))

    fun schedule(ctx: Context, text: String, at: Long): Item {
        val store = Stores.get(ctx, "reminders")
        // Same text within one minute of an already-pending reminder = duplicate (double tap / repeated voice command).
        store.all().firstOrNull { it.text.equals(text, true) && Math.abs(it.extra - at) < 60_000L }?.let { return it }
        val item = store.add(text, at)
        val delay = maxOf(0L, at - System.currentTimeMillis())
        val req = OneTimeWorkRequestBuilder<ReminderWorker>()
            .setInitialDelay(delay, TimeUnit.MILLISECONDS)
            .setInputData(workDataOf("id" to item.id, "t" to text)).build()
        WorkManager.getInstance(ctx).enqueueUniqueWork("rem_${item.id}", ExistingWorkPolicy.REPLACE, req)
        Alarms.set(ctx, item.id, text, at)
        return item
    }

    fun cancel(ctx: Context, id: Long) {
        WorkManager.getInstance(ctx).cancelUniqueWork("rem_$id")
        Alarms.cancel(ctx, id)
        Stores.get(ctx, "reminders").remove(id)
    }

    /** See [ReminderParser.parse]. */
    fun parse(raw: String, now: Long = System.currentTimeMillis()): Pair<Long, String>? = ReminderParser.parse(raw, now)
}
