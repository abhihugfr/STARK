package com.avi.jarvis
import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.os.Handler
import android.os.Looper
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import com.google.firebase.firestore.DocumentChange
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.firestore.MetadataChanges
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import org.json.JSONObject

enum class ConnState { OFFLINE, CONNECTING, CONNECTED }
data class AiReq(val pid: String, val mid: String, val from: String, val question: String)

/**
 * Live Connected Mode state: pairings, per-pairing message listeners, presence heartbeat (only while the app is
 * on screen), connection status and network-change handling. Firestore itself reconnects with back-off; we add
 * a status indicator, a network callback and a manual Reconnect.
 */
object Link {
    val pairings = mutableStateListOf<Pairing>()
    val state = mutableStateOf(ConnState.OFFLINE)
    val error = mutableStateOf("")
    val lastSeen = mutableStateMapOf<String, Long>()
    val aiInbox = mutableStateListOf<AiReq>()

    private val main = Handler(Looper.getMainLooper())
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var pairReg: ListenerRegistration? = null
    private val pairRegs = mutableMapOf<String, List<ListenerRegistration>>()
    private var beat: Job? = null
    private var cb: ConnectivityManager.NetworkCallback? = null
    private var gotServer = false
    private var userId: String? = null

    fun start(ctx: Context) {
        val app = ctx.applicationContext
        val me = Cloud.uid
        if (!Cloud.configured(app) || me == null) return
        if (userId == me && pairReg != null) { startBeat(); refresh(app); return }
        stop(app)
        userId = me
        refresh(app)
        aiInbox.addAll(AiInbox.load(app))
        Cloud.refreshToken()
        // Sharing window still open (e.g. the app was killed): resume the visible service; otherwise switch everything off.
        if (Cloud.anyLocalSharing(app)) {
            if (Cloud.locUntil(app) > System.currentTimeMillis()) LocationShareService.start(app) else Cloud.stopAllSharing(app)
        }
        pairReg = FirebaseFirestore.getInstance().collection("pairings").whereArrayContains("members", me)
            .addSnapshotListener(MetadataChanges.INCLUDE) { snap, err ->
                if (err != null) { error.value = Cloud.friendly(err); return@addSnapshotListener }
                if (snap == null) return@addSnapshotListener
                gotServer = !snap.metadata.isFromCache
                refresh(app)
                val list = snap.documents.mapNotNull { Cloud.toPairing(it, me) }.filter { it.status != "revoked" }
                pairings.clear(); pairings.addAll(list)
                val active = list.filter { it.status == "active" }
                val activeIds = active.map { it.id }.toSet()
                pairRegs.keys.filter { it !in activeIds }.forEach { k -> pairRegs.remove(k)?.forEach { it.remove() } }
                active.filter { it.id !in pairRegs }.forEach { attach(app, it, me) }
                val seen = Stores.get(app, "seen")
                list.filter { it.status == "pending" && !it.requestedByMe }.forEach { p ->
                    val key = "pair_" + p.id
                    if (seen.all().none { it.text == key }) {
                        seen.add(key, 0, 500)
                        Notifs.connected(app, "Pairing request", "${p.label} connect karna chahta hai. JARVIS > Connect mein accept ya reject karo.", key.hashCode())
                    }
                }
            }
        val cm = app.getSystemService(ConnectivityManager::class.java)
        val callback = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) { main.post { refresh(app) } }
            override fun onLost(network: Network) { main.post { gotServer = false; refresh(app) } }
        }
        try { cm.registerDefaultNetworkCallback(callback); cb = callback } catch (e: Exception) { }
        startBeat()
    }

    private fun attach(app: Context, p: Pairing, me: String) {
        val q = FirebaseFirestore.getInstance().collection("pairings").document(p.id).collection("messages")
            .whereEqualTo("to", me).whereEqualTo("readAt", null)
        val r1 = q.addSnapshotListener { snap, err ->
            if (err != null) { error.value = Cloud.friendly(err); return@addSnapshotListener }
            snap?.documentChanges?.filter { it.type == DocumentChange.Type.ADDED }?.forEach { ch ->
                val m = Cloud.toMsg(ch.document, p.id) ?: return@forEach
                Inbound.handle(app, m, p.label)
            }
        }
        val r2 = Cloud.listenPresence(p.id, p.other) { lastSeen[p.id] = it }
        pairRegs[p.id] = listOf(r1, r2)
    }

    private fun startBeat() {
        beat?.cancel()
        beat = scope.launch {
            while (isActive) {
                pairings.filter { it.status == "active" }.forEach { Cloud.beat(it.id) }
                delay(30_000)
            }
        }
    }

    /** App left the screen: stop the "I'm online" heartbeat. Background delivery is FCM's job. */
    fun background() { beat?.cancel(); beat = null }

    fun refresh(ctx: Context) {
        state.value = when {
            !Phone.online(ctx) -> ConnState.OFFLINE
            gotServer -> ConnState.CONNECTED
            else -> ConnState.CONNECTING
        }
    }

    fun stop(ctx: Context) {
        beat?.cancel(); beat = null
        pairReg?.remove(); pairReg = null
        pairRegs.values.forEach { l -> l.forEach { it.remove() } }; pairRegs.clear()
        try { cb?.let { ctx.applicationContext.getSystemService(ConnectivityManager::class.java).unregisterNetworkCallback(it) } } catch (e: Exception) { }
        cb = null
        pairings.clear(); lastSeen.clear(); aiInbox.clear()
        gotServer = false; userId = null
        state.value = ConnState.OFFLINE
    }
}

/** Pending AI questions from the paired device. Persisted so a restart never loses them; max 5 per device, 24 h life. */
object AiInbox {
    private const val NAME = "ai_inbox"
    private const val TTL = 24 * 60 * 60_000L

    private fun parse(it: Item): AiReq? = try {
        val o = JSONObject(it.text); AiReq(o.getString("pid"), o.getString("mid"), o.getString("from"), o.getString("q"))
    } catch (e: Exception) { null }

    fun load(ctx: Context): List<AiReq> {
        val s = Stores.get(ctx, NAME)
        val now = System.currentTimeMillis()
        val out = mutableListOf<AiReq>()
        s.all().forEach { i ->
            val r = parse(i)
            if (r == null || now - i.time > TTL) s.remove(i.id) else out.add(r)
        }
        return out
    }

    fun add(ctx: Context, r: AiReq): Boolean {
        val s = Stores.get(ctx, NAME)
        val cur = s.all().mapNotNull { parse(it) }
        if (cur.any { it.mid == r.mid }) return false
        if (cur.count { it.pid == r.pid } >= 5) return false
        s.add(JSONObject().put("pid", r.pid).put("mid", r.mid).put("from", r.from).put("q", r.question).toString(), 0, 100)
        return true
    }

    fun remove(ctx: Context, r: AiReq) {
        val s = Stores.get(ctx, NAME)
        s.all().firstOrNull { parse(it)?.mid == r.mid }?.let { s.remove(it.id) }
    }
}
