import java.util.Properties

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

// Firebase is optional: the google-services plugin only runs when app/google-services.json exists
// (your own Firebase project's file; it is git-ignored and never committed).
if (file("google-services.json").exists()) {
    apply(plugin = "com.google.gms.google-services")
}

// Optional release signing: create keystore.properties (git-ignored) in the project root with
// storeFile=..., storePassword=..., keyAlias=..., keyPassword=...  Without it the release APK is built UNSIGNED.
val keystoreFile = rootProject.file("keystore.properties")
val keystoreProps = Properties().apply { if (keystoreFile.exists()) keystoreFile.inputStream().use { load(it) } }

android {
    namespace = "com.avi.jarvis"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.avi.jarvis"
        minSdk = 26
        targetSdk = 34
        versionCode = 7
        versionName = "0.7"
    }

    signingConfigs {
        create("release") {
            if (keystoreFile.exists()) {
                storeFile = rootProject.file(keystoreProps.getProperty("storeFile"))
                storePassword = keystoreProps.getProperty("storePassword")
                keyAlias = keystoreProps.getProperty("keyAlias")
                keyPassword = keystoreProps.getProperty("keyPassword")
            }
        }
    }

    buildTypes {
        debug {
            isDebuggable = true
        }
        release {
            // Minify is off on purpose: Firebase/osmdroid/zxing need keep-rules that are not verified yet.
            isMinifyEnabled = false
            isShrinkResources = false
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
            if (keystoreFile.exists()) signingConfig = signingConfigs.getByName("release")
        }
    }

    buildFeatures { compose = true }
    composeOptions { kotlinCompilerExtensionVersion = "1.5.14" }   // pairs with Kotlin 1.9.24
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    // Lint runs as its own report-only CI step; it must not block assembleDebug/assembleRelease.
    lint { abortOnError = false; checkReleaseBuilds = false; warningsAsErrors = false }
    testOptions { unitTests.isReturnDefaultValues = true }
    packaging { resources { excludes += "/META-INF/{AL2.0,LGPL2.1}" } }
}

dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.06.00"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-core")
    implementation("androidx.activity:activity-compose:1.9.0")
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.security:security-crypto:1.1.0-alpha06")
    implementation("androidx.work:work-runtime-ktx:2.9.0")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-play-services:1.8.1")
    implementation(platform("com.google.firebase:firebase-bom:33.1.2"))
    implementation("com.google.firebase:firebase-auth")
    implementation("com.google.firebase:firebase-firestore")
    implementation("com.google.firebase:firebase-messaging")
    // QR scanning (own camera screen, asks CAMERA permission only when you tap Scan) + QR generation
    implementation("com.journeyapps:zxing-android-embedded:4.3.0")
    // In-app map (OpenStreetMap, no API key)
    implementation("org.osmdroid:osmdroid-android:6.1.18")

    // Local JVM unit tests (pure logic: calculator, reminder parser, request normalisation, QR payload, response parsing)
    testImplementation("junit:junit:4.13.2")
    testImplementation("org.json:json:20240303")   // org.json is only a stub in android.jar on the JVM
}
