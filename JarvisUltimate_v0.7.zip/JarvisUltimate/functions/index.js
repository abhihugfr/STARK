// Wakes the recipient's phone with a DATA-ONLY push {pid, mid, type}. No message text is sent through FCM.
// Requires the Firebase Blaze (pay-as-you-go) plan to deploy. Free quota is large, but a billing account is needed.
const { onDocumentCreated } = require("firebase-functions/v2/firestore");
const { initializeApp } = require("firebase-admin/app");
const { getFirestore, FieldValue } = require("firebase-admin/firestore");
const { getMessaging } = require("firebase-admin/messaging");

initializeApp();

exports.notifyMessage = onDocumentCreated("pairings/{pid}/messages/{mid}", async (event) => {
  const m = event.data && event.data.data();
  if (!m || !m.to) return;
  const db = getFirestore();
  const pairing = await db.doc(`pairings/${event.params.pid}`).get();
  if (!pairing.exists || pairing.get("status") !== "active") return;
  const userRef = db.doc(`users/${m.to}`);
  const token = (await userRef.get()).get("fcmToken");
  if (!token) return;
  try {
    await getMessaging().send({
      token,
      data: { pid: event.params.pid, mid: event.params.mid, type: String(m.type) },
      // Rings expire quickly so a delayed push never makes a phone ring minutes later.
      android: { priority: "high", ttl: m.type === "ring" ? 60 * 1000 : 24 * 60 * 60 * 1000 },
    });
  } catch (e) {
    if (e.code === "messaging/registration-token-not-registered") await userRef.update({ fcmToken: FieldValue.delete() });
    else console.error(e);
  }
});
