// Run (needs Node 20, Java 17, firebase-tools):  cd firestore-tests && npm install &&
//   npx firebase emulators:exec --only firestore --project demo-jarvis "node --test"
// Status: written; NOT executed yet (the repair sandbox had no network, so the Firestore emulator could not be downloaded).
const { test, before, after } = require("node:test");
const fs = require("node:fs");
const { initializeTestEnvironment, assertSucceeds, assertFails } = require("@firebase/rules-unit-testing");
const firebase = require("firebase/compat/app");
require("firebase/compat/firestore");

const A = "aaaa", B = "bbbb", C = "cccc";           // A < B < C (sorted order matters for members[]/link id)
let env;
const ts = () => firebase.firestore.FieldValue.serverTimestamp();
const dbOf = (uid) => env.authenticatedContext(uid).firestore();
const seed = (fn) => env.withSecurityRulesDisabled((c) => fn(c.firestore()));
const future = () => firebase.firestore.Timestamp.fromMillis(Date.now() + 5 * 60000);

before(async () => {
  env = await initializeTestEnvironment({ projectId: "demo-jarvis", firestore: { rules: fs.readFileSync("../firestore.rules", "utf8") } });
});
after(async () => { await env.cleanup(); });

async function activePair(pid = "P1", users = [A, B]) {
  await seed(async (db) => {
    await db.doc(`pairings/${pid}`).set({ members: users, requestedBy: users[1], status: "active", codeId: pid, labels: {} });
  });
}

test("pairing: code creates one pairing + link; second use is denied", async () => {
  await seed((db) => db.doc("pairCodes/CODE000001").set({ ownerUid: A, ownerLabel: "a", expiresAt: future(), used: false }));
  const db = dbOf(B);
  const batch = () => { const b = db.batch();
    b.set(db.doc("pairings/CODE000001"), { members: [A, B], requestedBy: B, status: "pending", labels: { [A]: "a", [B]: "b" }, codeId: "CODE000001", createdAt: ts() });
    b.set(db.doc(`links/${A}_${B}`), { pid: "CODE000001", members: [A, B] }); return b.commit(); };
  await assertSucceeds(batch());
  await assertFails(batch());                               // reuse of the same code
});

test("pairing: duplicate pair with a different code is denied while a link exists", async () => {
  await seed((db) => db.doc("pairCodes/CODE000002").set({ ownerUid: A, ownerLabel: "a", expiresAt: future(), used: false }));
  const db = dbOf(B);
  const b = db.batch();
  b.set(db.doc("pairings/CODE000002"), { members: [A, B], requestedBy: B, status: "pending", labels: { [A]: "a", [B]: "b" }, codeId: "CODE000002", createdAt: ts() });
  b.set(db.doc(`links/${A}_${B}`), { pid: "CODE000002", members: [A, B] });
  await assertFails(b.commit());
});

test("only the non-requester can accept; outsider cannot touch", async () => {
  await seed((db) => db.doc("pairings/P9").set({ members: [A, C], requestedBy: C, status: "pending", codeId: "P9", labels: {} }));
  await assertFails(dbOf(C).doc("pairings/P9").update({ status: "active" }));   // requester
  await assertFails(dbOf(B).doc("pairings/P9").update({ status: "active" }));   // outsider
  await assertSucceeds(dbOf(A).doc("pairings/P9").update({ status: "active" }));
});

test("ring and signal need the receiver's permission", async () => {
  await activePair();
  const msg = (type, body) => ({ from: A, to: B, type, body, sentAt: ts(), readAt: null });
  await assertFails(dbOf(A).collection("pairings/P1/messages").add(msg("ring", "ring")));      // no perms doc: default deny
  await assertSucceeds(dbOf(A).collection("pairings/P1/messages").add(msg("text", "hi")));
  await seed((db) => db.doc(`pairings/P1/perms/${B}`).set({ allowRing: true, allowSignals: false, allowAi: false, shareLocation: false }));
  await assertSucceeds(dbOf(A).collection("pairings/P1/messages").add(msg("ring", "ring")));
  await assertFails(dbOf(A).collection("pairings/P1/messages").add(msg("signal", "hello")));  // signals still off
  await assertFails(dbOf(A).collection("pairings/P1/messages").add({ ...msg("text", "x"), from: B })); // spoofed sender
});

test("only the recipient may mark read", async () => {
  await activePair("P2");
  let id;
  await seed(async (db) => { const r = await db.collection("pairings/P2/messages").add({ from: A, to: B, type: "text", body: "x", sentAt: new Date(), readAt: null }); id = r.id; });
  await assertFails(dbOf(A).doc(`pairings/P2/messages/${id}`).update({ readAt: ts() }));
  await assertSucceeds(dbOf(B).doc(`pairings/P2/messages/${id}`).update({ readAt: ts() }));
});

test("location is readable only when BOTH have sharing on; only the owner writes", async () => {
  await activePair("P3");
  await seed(async (db) => {
    await db.doc(`pairings/P3/perms/${A}`).set({ allowRing: false, allowSignals: false, allowAi: false, shareLocation: true });
    await db.doc(`pairings/P3/perms/${B}`).set({ allowRing: false, allowSignals: false, allowAi: false, shareLocation: false });
    await db.doc(`pairings/P3/location/${A}`).set({ lat: 1, lng: 2, acc: 5, updatedAt: new Date() });
  });
  await assertFails(dbOf(B).doc(`pairings/P3/location/${A}`).get());                      // B has not consented
  await seed((db) => db.doc(`pairings/P3/perms/${B}`).update({ shareLocation: true }));
  await assertSucceeds(dbOf(B).doc(`pairings/P3/location/${A}`).get());
  await assertFails(dbOf(C).doc(`pairings/P3/location/${A}`).get());                      // outsider
  await assertFails(dbOf(B).doc(`pairings/P3/location/${A}`).set({ lat: 9, lng: 9, acc: 1, updatedAt: ts() })); // B can't write A's
  await assertSucceeds(dbOf(A).doc(`pairings/P3/location/${A}`).set({ lat: 3, lng: 4, acc: 5, updatedAt: ts() }));
});

test("revoked pairing: nothing readable", async () => {
  await seed((db) => db.doc("pairings/P4").set({ members: [A, B], requestedBy: B, status: "revoked", codeId: "P4", labels: {} }));
  await assertFails(dbOf(A).collection("pairings/P4/messages").get());
});

test("consent switches can only be written by their owner and only while the pairing is active", async () => {
  await activePair("P5");
  const perms = { allowRing: true, allowSignals: false, allowAi: false, shareLocation: false };
  await assertSucceeds(dbOf(A).doc(`pairings/P5/perms/${A}`).set(perms));
  await assertFails(dbOf(A).doc(`pairings/P5/perms/${B}`).set(perms));            // cannot grant on behalf of the other side
  await assertFails(dbOf(C).doc(`pairings/P5/perms/${C}`).set(perms));            // outsider
  await assertFails(dbOf(A).doc(`pairings/P5/perms/${A}`).set({ ...perms, extra: 1 })); // unknown field
  await seed((db) => db.doc("pairings/P5").update({ status: "revoked" }));
  await assertFails(dbOf(A).doc(`pairings/P5/perms/${A}`).set(perms));            // revoked: frozen
});

test("a revoked pairing cannot be re-activated", async () => {
  await seed((db) => db.doc("pairings/P6").set({ members: [A, B], requestedBy: B, status: "revoked", codeId: "P6", labels: {} }));
  await assertFails(dbOf(A).doc("pairings/P6").update({ status: "active" }));
});

test("pairing code cannot be listed and expired codes cannot create a pairing", async () => {
  await seed((db) => db.doc("pairCodes/CODEEXPIRE").set({ ownerUid: A, ownerLabel: "a", expiresAt: firebase.firestore.Timestamp.fromMillis(Date.now() - 60000), used: false }));
  await assertFails(dbOf(B).collection("pairCodes").get());
  const b = dbOf(B).batch();
  b.set(dbOf(B).doc("pairings/CODEEXPIRE"), { members: [A, B], requestedBy: B, status: "pending", labels: { [A]: "a", [B]: "b" }, codeId: "CODEEXPIRE", createdAt: ts() });
  b.set(dbOf(B).doc(`links/${A}_${B}`), { pid: "CODEEXPIRE", members: [A, B] });
  await assertFails(b.commit());
});
