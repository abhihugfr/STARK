# Architecture
Single `app` module, MVVM-lite for now (state in Compose, logic in objects). Move to ViewModels as screens grow.

- Brain.kt: Anthropic API (HttpURLConnection, retries, error mapping). Key from encrypted Prefs.
- Commands.kt: local command router (offline-capable) then AI fallback. `bg=true` from the wake service.
- Phone.kt: device actions. Reminders.kt: WorkManager reminders + notifications.
- Store.kt: JSON files in app-private storage: memories, notes, reminders, chat (not encrypted; secrets never go here).
- WakeService.kt: foreground mic service looping SpeechRecognizer for "JARVIS".
- Cloud.kt: Firebase Auth, pairing (code/QR), messages, perms, presence, location, FCM token. Link.kt: live listeners, status, reconnect.
- Inbound.kt: one-shot handling of incoming items (notification / signal buzz / RemoteRing / AI inbox) + custom Signals.
- Fcm.kt: data-only push wake-up; fetches the message itself from Firestore. functions/index.js sends the push (Blaze plan).
- LocationShare.kt: visible foreground service, only while the owner has sharing ON. Qr.kt: QR drawing (ZXing).

## Connected Mode data model (Firestore)
users/{uid}                      profile (own only)
pairCodes/{code}                 {ownerUid, ownerLabel, expiresAt, used}  get-by-id only
links/{minUid_maxUid}            {pid, members}  one pending/active pairing per pair (created/deleted with the pairing, batched)
pairings/{pid}                   pid == codeId (single use). {members[2] sorted, requestedBy, status pending|active|revoked, labels, codeId, createdAt}
pairings/{pid}/messages/{mid}    {from,to,type text|signal|ring|locreq|ai_q|ai_a, body<=1000, sentAt, readAt}
pairings/{pid}/perms/{uid}       {allowRing, allowSignals, allowAi, shareLocation}  (uid = the one who grants)
pairings/{pid}/location/{uid}    {lat,lng,acc,updatedAt}  readable only if BOTH members have shareLocation=true
pairings/{pid}/presence/{uid}    {lastSeen}
Rules: everything under a pairing needs an ACTIVE pairing + membership; ring/signal/ai_q creation is denied by the
SERVER unless the recipient's perms doc allows it (default deny). The receiver app re-checks locally too.

## Remote-command safety
Allow-list only: text, signal:<name>, ring, locreq, ai_q/ai_a. No shell, no arbitrary intents, no hidden actions.
Ring: max 30 s, alarm stream, visible notification with Stop, ignored if older than 3 min. Location: foreground
service + persistent notification, 4 h auto-stop. AI relay: receiver approves; the answer is generated WITHOUT
the owner's memories/notes and can be edited/discarded before sending.
Not done: end-to-end encryption (Firebase can read message text), App Check, receipts beyond readAt.

## Other modules (v0.4)
Automation.kt: local rules (battery<=N%, daily time) run by 15-min WorkManager; action = local command only.
Calc.kt: offline calculator. WakeService: idle auto-off (Settings slider), low-battery stop (<15%), error back-off; still NOT a true wake-word engine.
Map.kt: osmdroid map (opt-in). AiInbox (Link.kt): persisted, capped AI-question queue.
