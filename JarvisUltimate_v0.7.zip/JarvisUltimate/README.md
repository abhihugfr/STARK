# JARVIS Ultimate v0.6 (audit + repair + features pass)
**Honest status:** v0.5 is a code audit and repair done in a sandbox that had **no Android SDK and no network** (Maven, Google and npm were
unreachable). So: **no APK was built, nothing was run on a phone/emulator, Lint did not run, and the Firestore emulator tests did not run.**
What *was* executed: JUnit-style tests of the pure-logic code (calculator, reminder parser, chat history, memory ranking, automation logic: 28/28 pass,
compiled with the Kotlin 2.0.21 compiler bundled in Gradle), Kotlin parser pass over all sources (no syntax errors), `node --check` on the
Cloud Function and rules tests. Model IDs were checked against the official Anthropic models page.
See REPAIR_REPORT.md for every bug found/fixed and the exact test results.

**Wake word, honestly:** this is NOT a hardware/low-power wake-word engine. It loops Android's `SpeechRecognizer` and string-matches
"jarvis" in the transcript. It costs battery, may beep between sessions and may use Google's servers for recognition.

## Build the APK on GitHub (no PC tools needed)
1. Create a **private** GitHub repository. Upload everything in this folder (keep `.github/`, `gradle/`, `gradlew`, `.gitattributes`).
   Do NOT upload `google-services.json`, keystores or API keys (they are git-ignored).
2. Open the repo > **Actions** tab > enable workflows if asked > **Build APK** > **Run workflow** (branch main).
3. Wait ~10-15 min. Open the finished run > **Artifacts** > download `jarvis-debug-apk` (zip) > unzip > `app-debug.apk`.
4. Copy it to your phone, allow "install unknown apps", install. (`jarvis-release-apk-unsigned` is also produced; it cannot be installed until signed.)
5. If the run fails: open the failed step, copy the red error text, send it to me. That is expected possible on a first-ever build.
Optional (Connected Mode in the cloud-built APK): Repo > Settings > Secrets and variables > Actions > New secret `GOOGLE_SERVICES_JSON`
= base64 of your own `google-services.json` (`base64 -w0 google-services.json`).

## Build locally instead
Android Studio (Koala+, JDK 17): File > Open > this folder > Sync > Build > Build APK(s). Or terminal: `./gradlew :app:assembleDebug`
(stock Gradle 8.7 wrapper is included; Windows: `gradlew.bat`). Tests: `./gradlew :app:testDebugUnitTest`, lint: `./gradlew :app:lintDebug` (lint errors fail the build).
Output: `app/build/outputs/apk/debug/app-debug.apk`.

Toolchain pinned: Gradle 8.7, AGP 8.5.2, Kotlin 1.9.24 + Compose compiler 1.5.14, JDK 17, compileSdk/targetSdk 34, minSdk 26.
Release builds: unsigned unless you create `keystore.properties` (storeFile, storePassword, keyAlias, keyPassword) in the project root.

## Setup
1. Install APK, Settings tab: paste your own Anthropic API key (stored only in the phone's encrypted storage; never in source/APK).
2. Connected Mode is optional: follow SETUP_FIREBASE.md (own private Firebase project, `google-services.json` stays out of git).

## Commands (Hindi/English/Hinglish)
battery | flashlight on/off | open whatsapp | alarm 7:30 am | timer 5 minute | volume up/down | mute | play/pause music | next song |
wifi settings | network status | device info | what time | 12 plus 5 times 3 | flip a coin | call 9876543210 (opens dialer) | share <text> |
yaad rakho <fact> | note: <text> | mere notes | meri memories | 10 minute baad chai yaad dilao | remind me at 8 pm to call
Wake word: Core tab > Wake word tile (mic permission + visible notification). Memory tab: Memory / Notes / Reminders / Auto (automations).

## Privacy
No ads/analytics/trackers. Camera only when you tap Scan QR. Location only while you switched sharing on for a paired device, with a visible
notification. Remote actions are an allow-list (text, signal, ring, location request, AI question) and each needs the receiver's switch.
Keep the GitHub repository private. Do not commit API keys, `google-services.json`, keystores.
