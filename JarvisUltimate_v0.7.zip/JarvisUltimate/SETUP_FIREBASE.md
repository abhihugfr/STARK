# Firebase setup (private, free Spark plan is enough for this stage)
1. console.firebase.google.com > Add project (keep Analytics off).
2. Project settings > Add Android app > package name `com.avi.jarvis`. Download `google-services.json`
   and put it in `app/` (it is git-ignored; never commit it).
3. Build > Authentication > Get started > enable **Email/Password**.
4. Build > Firestore Database > Create (production mode). Open Rules, paste `firestore.rules`, Publish.
5. Firestore > TTL policies: add a policy on collection `pairCodes`, field `expiresAt` so old codes auto-delete.
6. Rebuild. Connect tab should now show the login form.
7. Repeat steps on BOTH phones with the same Firebase project; create a different account on each phone.

Pairing test: Phone A: Create pairing code + QR. Phone B: Scan QR (or type the code) > request is sent.
Phone A (updates live): Accept. Either phone can Revoke. A code makes at most one pairing ever (the pairing id is the code).

Known limits: the code is ~50 bits and lives 10 minutes; a stranger who guesses it can only create a PENDING request that you must
accept. For stronger protection add Firebase App Check later. Rejecting/revoking never lets the same code be used again.

## Round 3 additions
8. Re-publish `firestore.rules` (changed again in v0.4: `links/` collection, pairing id == code). Old pairings from v0.2/v0.3 will not work; re-pair.
9. Cloud Messaging is enabled by default. For background delivery deploy the function (needs Blaze plan = billing account;
   usage for two phones stays inside the free quota, but it is NOT strictly "no card"): `npm i -g firebase-tools`, `firebase login`,
   `firebase use <project>`, `cd functions && npm install && cd .. && firebase deploy --only functions,firestore:rules`.
   Without it everything works only while JARVIS's process is alive (messages arrive via the live listener, no push when closed).
10. QR scanning asks for camera permission only when you tap "Scan QR". Location asks only when you switch sharing on.
11. Optional rules tests (emulator, not yet run by the author): `cd firestore-tests && npm install && npx firebase emulators:exec --only firestore --project demo-jarvis "node --test"`.
12. The in-app map uses OpenStreetMap tiles (free, no key). It loads only when you tap "Map dikhao".
