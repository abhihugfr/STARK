# STATUS v0.7 (honest)
**v0.7 background changes (written, not compiled/run on a phone):** partial wake-lock + foreground mic service (listens with screen off); mic restarts when the app is opened and a notification is shown after reboot (Android forbids starting a mic service from boot); exact alarms (setAlarmClock) for reminders/timers/alarms, re-armed after reboot, WorkManager kept as backup; voice timer/alarm now work in the background; open-app/settings/dial/share in background post a notification you tap (Android blocks screens from background); Settings has a "Battery unrestricted" button; idle auto-off default is now "never". Pure-logic AlarmLogic checked with kotlinc; Android code NOT compiled here.

# (v0.6 notes below)
**Still not built or run on a device.** See REPAIR_REPORT.md for exactly what was executed (28 pure-logic unit tests pass locally) and what was not
(Gradle build, APK, Lint, emulator, Firestore rules tests, any phone testing). Feature table below is from earlier rounds: "written" means written and desk-reviewed only.

| Item | State |
|---|---|
| Gradle wrapper | gradlew + gradlew.bat + properties added. The binary gradle-wrapper.jar is NOT included (cannot create offline); gradlew downloads the official 8.7.0 jar if missing and CI regenerates it. Never executed. |
| Gradle/Kotlin compatibility | Versions chosen from documented compatibility (Gradle 8.7 / AGP 8.5.2 / Kotlin 1.9.24 / Compose compiler 1.5.14 / JDK 17). Not verified by a build. |
| Fix compile errors | Desk-reviewed all files, fixed risky spots. Real compile unknown. |
| Verify dependencies | Added osmdroid 6.1.18, zxing-android-embedded 4.3.0, firebase-messaging (BOM 33.1.2). Not resolved against Maven. |
| Debug APK | NOT built (workflow ready; first run not yet done). |
| README/STATUS accuracy | Rewritten. Removed stale "QR not built" / old pairing steps. |

## Priority 2 - Connected Mode (all written, NONE tested)
| Item | State |
|---|---|
| QR pairing security review | Done by review: single-use enforced by pairing id == code, 10-min expiry, explicit accept, QR payload only holds the code. Residual risk: ~50-bit code can be brute-forced to create a pending request (needs your accept). App Check not added. |
| No code reuse / no duplicate pairings | Written: server rules (`links/` + pairing id) and client pre-check. Emulator tests written, not run. |
| Firestore rules review | Tightened (signal/ring/ai body limits, links, sorted members). Not run in emulator. |
| Two-way messaging test | NOT tested (needs two phones). |
| Ring / signals test | NOT tested. |
| FCM delivery/failure | Fetch-failure fallback notification, never rings if unverified, token refresh each start, 60 s TTL for rings. Function not deployed. |
| Location consent + auto-stop | Fixed a real bug (expiry depended on movement): now a timer, resumes/expires on app start, stops service when last sharing is off, stale-location warning. Not tested. |
| Map | osmdroid OpenStreetMap, opt-in button. Not tested. |
| AI-to-AI approval | Persisted queue, 5-pending cap, 24 h expiry, draft/edit/send/deny. Still NOT end-to-end encrypted. Not tested. |

## Priority 3 - advanced JARVIS
| Item | State |
|---|---|
| Persistent memory with edit/delete | Existed since Round 2 (Memory tab). Not retested. |
| Better wake word + battery | Idle auto-off, low-battery stop, error back-off. NOT a real wake-word engine (still loops SpeechRecognizer). |
| Smart automation | Written: battery/daily-time rules -> local commands, ~15 min precision. Not tested. |
| Offline voice commands | Local commands work offline; wake service prefers offline recognition. Depends on device language packs. Added calculator, timer, dial, coin. Not tested. |
| Custom personality | Existed (Settings > Personality). |
| Multiple model selection | Existed (Settings: Sonnet/Haiku/Opus + free text). |
| Voice response speed | Voice replies capped (300 tokens, "2 short sentences"). No streaming. Not measured. |

## Priority 4 - privacy
Repo private: your responsibility (README says so). No secrets in source (grepped). Rules are default-deny for remote actions. No background/hidden tracking: location only via visible service.

## Next step
Run the GitHub Actions workflow or build in Android Studio, send the first error list; then the two-phone test plan (STATUS history in Round 3 zip) and rules tests.
