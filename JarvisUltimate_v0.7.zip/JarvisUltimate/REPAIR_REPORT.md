# REPAIR REPORT v0.6 (audit + repair, honest)

> v0.6 additions are in the last section. Everything below the table is from v0.5 and still applies.

## What could and could not be run
| Step | Result |
|---|---|
| Gradle sync / clean build / debug APK / release APK | **NOT RUN.** Sandbox has no Android SDK; dl.google.com, Maven Central, services.gradle.org unreachable. Cloud CI workflow (`Build APK`) is the way to produce it. |
| Kotlin compilation of Android code | **NOT RUN** (no android.jar / Compose / Firebase jars). A parser-level pass of all 24 sources with the Kotlin 2.0.21 compiler found **no syntax errors**; every other message was "unresolved reference" caused by the missing Android classpath. This does NOT prove the code type-checks. |
| Unit tests | **Ran locally, 28/28 pass (v0.6):** `CalcTest`(7), `ChatHistoryTest`(5), `ReminderParserTest`(6), `MemoryRankTest`(4), `AutomationLogicTest`(6) (compiled with Gradle's bundled Kotlin 2.0.21 and a tiny JUnit shim). `BrainParseTest` and `QrPayloadTest` are in the repo but need the Android/org.json classpath: **not run**. |
| Lint | **NOT RUN.** `abortOnError` is now `true` (it was `false`, which hid errors): the first real lint run may surface issues to fix. |
| Firestore rules emulator tests | **NOT RUN** (emulator jar and npm packages not downloadable). 3 tests added (10 total). `node --check` passes. |
| Cloud Function | `node --check` OK; not deployed. |
| Install/startup on emulator or phone | **NOT RUN**, no emulator. |
| Model IDs | **Verified** against platform.claude.com models overview: `claude-sonnet-5-5`, `claude-haiku-5-5`, `claude-opus-5-5`, `claude-fable-5-2` (Fable added as a 4th button; free-text model field still works). |
| Gradle wrapper | Stock 8.7 wrapper jar + scripts generated with `gradle wrapper` and included (was missing). |

## Bugs found and fixed
| # | File | Bug | Fix |
|---|---|---|---|
| 1 | WakeService | `startForeground(MICROPHONE)` throws `SecurityException` on Android 14+ without mic permission, inside the service = **app crash** | Permission checked in `start()`; `startFg()` wrapped in try/catch, service stops cleanly |
| 2 | WakeService | TTS used before init finished / failed: `afterSpeak` never fired, so the **listen loop died silently forever** | `ttsReady` flag, `Speech.say` returns success, speak watchdog (25 s), continuation always runs exactly once |
| 3 | WakeService | Second Start tap/intent created a second loop with duplicate pending restarts | `started` guard, single pending restart runnable, recognizer *generation* counter (late callbacks from destroyed recognizers ignored), `busy` flag blocks recognition while a command is processed/spoken |
| 4 | WakeService | Every error restarted the recognizer forever (e.g. no offline language pack = endless 3 s loop) | Errors classified: silence = gentle slow-down; real failures = exponential back-off, **stop after 8 in a row**; offline preference dropped on language errors |
| 5 | WakeService | Uncaught exception in `Commands.process` coroutine would crash the app | try/catch, spoken error message |
| 6 | LocationShareService | Early `stopSelf()` paths never called `startForeground()` after `startForegroundService()` = `ForegroundServiceDidNotStartInTime` crash | `startForeground` first, always; permission pre-check in `start()` |
| 7 | Cloud/ConnectedScreen | Read-receipt loop: pending `readAt` server timestamp parsed as null, so every snapshot re-marked messages read -> endless writes | `readAt` parsed with ESTIMATE; per-process dedupe set in `markReadId` |
| 8 | ConnectedScreen | Location listener dies permanently after a permission error (other side not yet consenting), so location never appeared when they later enabled sharing | Listener re-attached whenever either side's consent flag changes |
| 9 | ConnectedScreen | Logout left location sharing + service running | Sharing stopped before sign-out |
| 10 | Brain | Consecutive same-role/leading-assistant turns after a failed request could produce an API 400 | `ChatHistory.normalize` (merge, drop blanks/leading assistant); connection always `disconnect()`ed in `finally`; 408/504 retried; blank model falls back to default |
| 11 | firestore.rules | Consent switches (`perms`) writable on a revoked pairing | Write now requires `isActive(pid)` (+ test) |
| 12 | Build | `gradle-wrapper.jar` missing; lint errors suppressed; no test deps; no launcher icon | Wrapper added; `abortOnError=true`; JUnit + org.json test deps; adaptive launcher icon |
| 13 | CI | Only built APKs | Now also runs unit tests and lint, uploads reports |
| 14 | Settings | About showed stale "v0.2" | Reads real versionName |

## Reviewed and found OK (by reading; not by running)
Anthropic request/response format and 400/401/403/404/429/5xx handling; encrypted API-key storage (EncryptedSharedPreferences, no key in source);
manifest permissions (INTERNET, ACCESS_NETWORK_STATE, SET_ALARM, RECORD_AUDIO, POST_NOTIFICATIONS, FOREGROUND_SERVICE + MICROPHONE/LOCATION types, location, VIBRATE: all used; camera comes from the zxing library only when Scan is tapped);
Android 13 notification permission flow; Android 14 FGS types declared; pairing single-use design (pairing id == code, links/ uniqueness); rules default-deny on remote actions and mutual-consent location;
Cloud Function (data-only FCM, 60 s ring TTL).

## Known limitations (unchanged by design)
- Reminders use WorkManager (can be a few minutes late in Doze). Automations ~15 min precision. No exact-alarm permission requested on purpose.
- Wake word is continuous SpeechRecognizer, not a wake-word engine; start it while the app is visible (Android 12+). Behaviour with screen locked/background depends on the device's recognizer and was not tested.
- Voice launching apps/settings/alarms is refused in background (Android restriction) and says so.
- AI-to-AI relay is not end-to-end encrypted. App Check not enabled.
- compileSdk/targetSdk 34 kept (AGP 8.5.2 / Gradle 8.7 / Kotlin 1.9.24 / Compose compiler 1.5.14 / JDK 17 is a documented-compatible set). Apps targeting 34 run on Android 15/16, but Google Play now requires a newer target for new uploads: bump AGP/compileSdk together after the first green build.
- Not verified on Android 8-16 devices at all.

## Manual steps you still must do
1. Push to a private GitHub repo and run **Build APK** (or Android Studio). Send me the first error log if it fails: first-ever compile is likely to reveal issues I could not see.
2. Connected Mode: Firebase project, `google-services.json` in `app/`, Email/Password on, publish `firestore.rules`, deploy `functions/` (Blaze plan), run rules tests: `cd firestore-tests && npm i && npx firebase emulators:exec --only firestore --project demo-jarvis "node --test"`. See SETUP_FIREBASE.md.
3. Release signing: `keystore.properties` (see README).

## v0.6 round (final-master request): what was done
Same sandbox limits: no Android SDK, no network => **still no APK, no Gradle run, no lint, no emulator, no device test.** Nothing below is "verified on device".
Done in code (desk-reviewed + pure-logic tests run locally, 28/28):
- **AI status indicator** (Dashboard, Chat, Settings): Not tested / Connecting / Connected / Offline / API error. "Connected" is set only after a real successful API response; Offline when no network or timeout; API error for 4xx/5xx. Last error text shown.
- **Token usage tracking:** input/output tokens from the API `usage` field, accumulated in encrypted prefs, shown in Settings with reset.
- **Context management:** history trimmed to ~12 000 characters (oldest turns dropped, always starts with a user turn). **Relevant-memory selection:** only memories matching the question + the 8 most recent are sent (was: last 50 blindly).
- **Memory search** (Memory and Notes tabs). Chat history is cleared separately (existing "Clear chat" button; memories untouched).
- **Automation enable/disable switch**; firing logic extracted to a tested pure function.
- **Duplicate reminders prevented** (same text within 1 minute).
- **Client-side send throttle** (ring: 10 s, other messages 0.8 s). Server-side rate limiting is NOT implemented (Firestore rules cannot count requests without extra bookkeeping documents).
- **Privacy screen** in Settings; AI-to-AI text now says: encrypted in transit (TLS), **not** end-to-end.
- **CI:** Firestore rules job no longer `continue-on-error` (a failing rules test now turns the run red) and uploads its log.
Existing and unchanged: WhatsApp/app launch ("open whatsapp"), dialer, alarms/timers via system intents, volume/media keys, Wi-Fi settings, share, location request message.

## Requested but NOT done (and why)
| Item | Status |
|---|---|
| Real wake-word engine | **Not implemented.** Porcupine needs a per-developer AccessKey from Picovoice (credentials) and its model/SDK come from Maven; open-source options (openWakeWord, Vosk keyword spotting) need model files and native libs that could not be downloaded here, and could not be compiled or tried without the SDK. Shipping unverified native audio code would risk breaking the working build. The app still says plainly that it is SpeechRecognizer listening. Recommended next step once a first build is green: Porcupine (free personal AccessKey, custom "Jarvis" keyword is built-in) behind the existing WakeService loop. |
| Upgrading target SDK / AGP | Not changed: cannot be validated without a build. |
| Debug/release APK, signed release | Impossible here; CI produces them. Signing needs your keystore. |
| Emulator / two-device tests | Not possible here. Manual test list below. |
| Server-side rate limiting, App Check, E2E encryption | Not implemented. |
| Navigation redesign / voice assistant screen / confirmation dialogs | Not done this round (the existing five tabs are kept). Dial/alarm/share already open the system UI where the user confirms. |

## Billing (Firebase)
Authentication (email/password) and Firestore: free Spark tier is enough for two phones. **Cloud Functions (needed for push when the app is closed) require the Blaze plan** (a card is needed; cost is typically ~0 at this volume). FCM itself is free. Without Functions, messages still arrive while the app is open.

## Manual test checklist (nothing here has been run)
1. Install APK > first launch: notification prompt appears (Android 13+). 2. Settings: paste key > Test connection > chip turns "connected" and token counter rises; airplane mode > chip "offline". 3. Chat in Hindi/English/Hinglish. 4. Core tab > Wake word > allow mic > say "Jarvis, battery"; lock screen and repeat; Stop from notification. 5. Memory: add/edit/search/delete; say "yaad rakho ..."; Reminders: "10 minute baad chai yaad dilao" twice quickly (one reminder only). 6. Automation: add battery rule, toggle OFF, confirm it does not fire. 7. Two phones, Connected Mode: signup both, pair via QR, accept/reject/revoke, messages both ways with app closed (needs Functions), ring + Stop, location with both ON then expiry/OFF, AI question approve/deny. 8. Run the rules tests (CI job or local emulator).
